#!/usr/bin/python
import boto3


class FilterModule(object):
    def filters(self):
        return {
            'get_secret': self.get_secret
        }

    def get_secret(self, a_variable, kmsKeyId):
        client = boto3.client('secretsmanager', region_name='ap-southeast-1')

        response = client.get_secret_value(
            SecretId=a_variable
        )
        return response['SecretString'] 
