# Testing

```json
{
  "file_patterns": "*.yml",
  "shell_cmd": "rsync --delete -ru ~/ADA/ada-jenkinsslave/ jenkinsdev:/home/ec2-user/test/; ssh jenkinsdev ansible-playbook -c local /home/ec2-user/test/platform/ansible/ansible.yml",
  "keyfiles": "main.yml"
}
```
