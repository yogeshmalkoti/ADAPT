export VAULT_ADDR=https://vault.dev6.nonprod.c0.dbs.com
export VAULT_SKIP_VERIFY=1
