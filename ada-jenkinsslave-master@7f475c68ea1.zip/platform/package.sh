# setup scripts
rm -f $FILES_DIR
echo $FILES_DIR
mkdir -p $FILES_DIR/conf/
# mkdir -p $FILES_DIR/vars/
cp -pr conf/* $FILES_DIR/conf/
# cp -pr vars/* $FILES_DIR/vars/

# Zip and upload the platform/components directory to S3
echo "Creating ansible deployment package"
mkdir $FILES_DIR/ansible
rm -f $FILES_DIR/ansible/ansible.zip
zip -r $FILES_DIR/ansible/ansible.zip ansible
#rm -f $FILES_DIR
