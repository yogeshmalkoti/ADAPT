#!/bin/bash
_ENV=uat ./inventories/_ansible.sh "$@"