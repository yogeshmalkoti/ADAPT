#!/bin/bash
# TODO: Testing remove me

export no_proxy=127.0.0.1,localhost,169.254.169.253,169.254.169.254,dbs.com,s3.ap-southeast-1.amazonaws.com,s3-ap-southeast-1.amazonaws.com,dynamodb.ap-southeast-1.amazonaws.com

dev6_software_bucket=dbs-s3-dev6-sg-t1-ada-software
uat_software_bucket=dbs-s3-uatdatascience-sg-s1-ada-software
prod_software_bucket=dbs-s3-proddatascience-sg-g1-ada-software

if [ "$aws_accnt" = "dev6" ]; then
	export https_proxy=http://proxy.sin.services.nonprod.c0.dbs.com:3128

	elif [ "$aws_accnt" = "uatdatascience" ]; then
	export https_proxy=http://proxy.sin.services.nonprod.c0.dbs.com:3128
	source_bucket=${dev6_software_bucket}
	destination_bucket=${uat_software_bucket}
	elif [ "$aws_accnt" = "proddatascience" ]; then
	export https_proxy=http://proxy.sin.services.prod.c0.dbs.com:3128
	source_bucket=${uat_software_bucket}
	destination_bucket=${prod_software_bucket}
	else
	echo "ERROR! unknown AWS account $aws_accnt"
	exit 1
fi
export http_proxy=$https_proxy