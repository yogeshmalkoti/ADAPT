#!/bin/bash

BASEDIR=$(dirname "$0")
source $BASEDIR/common.sh
echo "curent dir is $_current_dir"

echo "copy from $source_bucket to $destination_bucket"

aws s3 sync s3://$source_bucket/  s3://$destination_bucket/ --acl bucket-owner-full-control --region ap-southeast-1
