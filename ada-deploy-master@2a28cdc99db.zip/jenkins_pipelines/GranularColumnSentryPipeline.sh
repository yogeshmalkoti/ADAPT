#---------Get The columns from the Mariadb and restrict the access to the groups----------------#


#---------Environment Check_________________#

#---------Jenkins Parameters--------------#

dbname=$1
GroupNames=$2
PATH_TO_KEYTAB=$3
PRINCIPAL=$4
HS_2=$5
CERTS_PATH=$6
ENV=$7
MDB_IP=$8
MDB_USER=$9
MDB_PASS=$10

if [ "$ENV" = "UAT" ]
  then
  DOMAIN=SVCSUAT.DBS.COM
elif [ "$ENV" = "PROD" ]
  then
  DOMAIN=SVCS.DBS.COM
fi
  
#---------DB.DATABASE - Paramater 1---------#

#---------Sentry Groupts - Paramter 2-----#

echo "Initializing Keytab"
echo
kinit -kt $PATH_TO_KEYTAB $PRINCIPAL





beelinecommandexecutor='beeline -u "jdbc:hive2://$HS_2:10000/default;ssl=true;sslTrustStore=$CERTS_PATH;trustStorePassword=changeit;principal=hive/_HOST@$DOMAIN"'


cd /tmp/deploycolumnsentry/
beeline -u "jdbc:hive2://$HS_2:10000/default;ssl=true;sslTrustStore=$CERTS_PATH;trustStorePassword=changeit;principal=hive/_HOST@$DOMAIN" --showHeader=false --outputformat=csv2 -e "use ${dbname};show tables;" > /tmp/tmp_file.csv

#cat /tmp/tmp_file.csv

while read tblname; do

tablename=$tblname
dbtableinstance=${dbname}.${tablename}

echo "Querying ${dbtableinstance} Maria DB For 10.92.151.127 Instance"
echo
mysql -h $MDB_IP -N --port=6603 -u $MDB_USER -p$MDB_PASS --execute="SELECT OBJ_ATTR_NAME FROM FRDV_TV.FC_OBJ_STRUCTURE WHERE OBJ_ID = (SELECT SOURCE_OBJECT_ID FROM FRDV_TV.FC_SRC_OBJ_CONFIGURATION WHERE DESTINATION_TABLE_NAME = '${tablename}') AND SENSITIVITY_CLASSIFICATION != 'Confidential' ORDER BY COLUMN_ORDER;" > `pwd`/non_sen_columns.txt

nonsencolumnlist=`cat non_sen_columns.txt | grep -v / | tr '\n' ','`
nonsencolumnlist=`echo ${nonsencolumnlist::-1}`
echo "Non-Sensitive column list - ${nonsencolumnlist}"
echo
rm -rf `pwd`/hqlgrantstatements.hql

#------------------------------Grant Access Template---------------------------------#
#echo "GRANT SELECT(${clmn}) ON TABLE ${dbtableinstance} TO ROLE role_name;"  >> `pwd`/hqlgrantstatements.hql

rolename=`echo ${dbname}_non_sensitive_role`

echo "${rolename} - Checking Role already Exists"

CheckRoleExists=$(${beelinecommandexecutor} -e "show grant role ${rolename};")
if [[ -z $CheckRoleExists ]]; then
  echo " Role cannot be found - Creating Role"
  ${beelinecommandexecutor} -e "CREATE ROLE ${rolename};GRANT SELECT(${nonsencolumnlist}) ON TABLE ${dbtableinstance} TO ROLE ${rolename};GRANT ROLE ${rolename} TO GROUP ${GroupNames};"
else
echo "Role Exists"
${beelinecommandexecutor} -e "GRANT SELECT(${nonsencolumnlist}) ON TABLE ${dbtableinstance} TO ROLE ${rolename};GRANT ROLE ${rolename} TO GROUP ${GroupNames};"
fi

echo
echo "Role Permissions - ${rolename}"
echo
beeline -u "jdbc:hive2://$HS_2:10000/default;ssl=true;sslTrustStore=$CERTS_PATH;trustStorePassword=changeit;principal=hive/_HOST@$DOMAIN" -e "show grant role ${rolename};"

echo "Groups - ${GroupNames}"
echo
echo "Grant Statements executed Successfully"
echo
echo "--------------------------------------X-------------------------------"

done </tmp/tmp_file.csv

kdestroy