node()
{
    
git branch:"SSB_ADA_Implementation_V1.0",credentialsId: '25693f78-0fa3-4f82-a016-c9dd84c72f7c', url: "https://gitlab.dev.apps.cs.sgp.dbs.com/SSB_DS/SSB_ADA_Implementation.git"
stage 'Download from Git'
UserKey="adasupp-adaprod"
sshagent (credentials: ["${UserKey}"])
{
    
sh "echo For Testing with the SSH AGENT on 5A machine"
sh "ssh -o StrictHostKeyChecking=no adasupp@x01gadaapp5a.vsi.sgp.dbs.com sh /home/adasupp/deploycolumnsentry/GranularColumnSentryPipeline.sh  $Database_Name $Group_Info $PATH_TO_KEYTAB $PRINCIPAL $HS_2 $CERTS_PATH $ENV $MDB_IP $MDB_USER $MDB_PASS"
}
}