#!/bin/bash
if [ ! -f "$HOME/.ansible.cfg" ]; then
echo "[defaults]
host_key_checking = False
[ssh_connection]
scp_if_ssh = True
" > "$HOME/.ansible.cfg"
fi

if [[ "$NODE_LABELS" = *AWS* ]]; then
    if [[ "$NODE_LABELS" = *DEV* ]]; then
        aws_accnt=dev6
    elif [[ "$NODE_LABELS" = *UAT* ]]; then
        aws_accnt=uatdatascience
    elif [[ "$NODE_LABELS" = *PROD* ]]; then
        aws_accnt=proddatascience
    fi
else
    echo "WARN: we are on-premise; need to work on setting up the environment"
    exit 1
fi

export https_proxy=http://proxy.sin.services.nonprod.c0.dbs.com:3128
export http_proxy=$https_proxy
export no_proxy=169.254.169.254,gitlab.dev.apps.cs.sgp.dbs.com,bitbucket.sgp.dbs.com

export base_location=/opt/jenkins/.ada_deploy_aws
export workspace=$1

PATH=$PATH:/usr/local/bin

mkdir -p c2e-inventories

# Checkout the inventories
git_bb_inventories=https://$pdcifgitchkout@bitbucket.sgp.dbs.com:8443/dcifgit/scm/ada/ada-inventories.git

# Checkout the inventories source control and get the changes
cd "c2e-inventories"
if [ -d ".git" ]; then
  git reset --hard
  git pull "$git_bb_inventories" "$aws_accnt"
else
  git clone -b "$aws_accnt" "$git_bb_inventories" .
fi
cd ..

export inventory_file=c2e-inventories/ADA-$adastack/ADA-$adastack.inventory
export extra_file=c2e-inventories/ADA-$adastack/extras.json

if [ ! -f "$inventory_file" ]; then
  >&2 echo "FATAL: Unknown adastack \"$adastack\""
  >&2 echo "Stacks present in c2e-inventories:"
  ls c2e-inventories
  exit 12
fi

# cleanup from previous runs:
rm .extras-*.json &>/dev/null || true

echo "AND: "~jenkins
[ -z "$HOME" ] && export HOME="/var/lib/jenkins"

echo "NOW HOME=$HOME"

envsubst < c2e-inventories/ADA-$adastack/extras.json > .extras-$adastack.json

cat .extras-$adastack.json

#zk_quoram=$(python zkquoram.py $adastack $WORKSPACE/roles/director/templates/$director_template.j2 2181 >&1)
#ansible-playbook -i "$inventory_file" \
#  -e @.extras-$adastack.json \
#  -e @$HOME/.priv.json \
#  -e "alluxio_zookeeper_address=$zk_quoram
#  -e "director_template=${director_template}" \
#  $tags $verbosity $_retry_limit \
#  $playbook

[ "$disable_krb" = "true" ] && krb_switch="#" || krb_switch=""

[ -n "$tags" ] && tags="--tags $tags"

if [ -n "$do_zk_quoram" ]; then

  zk_quoram=$(python $WORKSPACE/roles/director/files/zkquoram.py $adastack $WORKSPACE/roles/director/templates/$director_template.j2 2181 >&1)

  echo "Zookeeper Quoram " 
  echo $zk_quoram
  exit 0

fi

if [ -n "$do_reset_cdh" ]; then
  do_reset_cdh="-e do_reset_cdh=true"
fi

if [ -z "$vault_keytabs_download" ]; then
  if [ "$aws_accnt" = "dev6" ]; then
    vault_keytabs_download=${vault_dev6_keytabs_download}
  elif [ "$aws_accnt" = "uatdatascience" ]; then
    vault_keytabs_download=${vault_uatdatascience_keytabs_download}
  elif [ "$aws_accnt" = "proddatascience" ]; then
    vault_keytabs_download=${vault_proddatascience_keytabs_download}
  fi
fi

playbook=${playbook:-site.yml}

ansible-playbook -i "$inventory_file" \
  -e @.extras-$adastack.json \
  -e "id_mgt_ou_admin_secret=${id_mgt_ou_admin_secret}" \
  -e "director_template=${director_template}" \
  -e "krb_switch=${krb_switch}" \
  -e "sssd_reset=${sssd_reset}" \
  -e "base_location=${base_location}" \
  -e "workspace=${workspace}" \
  -e "vault_keytabs_download=${vault_keytabs_download}" \
  $do_reset_cdh $tags $verbosity $_retry_limit \
  $playbook $retry

#-e "alluxio_zookeeper_address=ada-${adastack}-master-0.c2e.dbs.com:2181,ada-${adastack}-master-1.c2e.dbs.com:2181,ada-${adastack}-master-2.c2e.dbs.com:2181,ada-${adastack}-master-3.c2e.dbs.com:2181,ada-${adastack}-master-4.c2e.dbs.com:2181" \
 #-e "alluxio_zookeeper_address=${zk_quoram}" \
