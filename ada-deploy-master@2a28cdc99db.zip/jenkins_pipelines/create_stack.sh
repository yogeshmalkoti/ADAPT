#!/bin/bash

[ -z "$adastack" ] && echo "FATAL!: the adastack variable is not defined" && exit

if [ "${#adastack}" -gt 4 ]; then
  echo "FATAL!: adastack variable length greater than 4"
  exit 1
fi

echo "Building $adastack"

_current_dir="$(pwd)"

########## terraform
export https_proxy=http://proxy.sin.services.nonprod.c0.dbs.com:3128
export http_proxy=$https_proxy
export no_proxy=169.254.169.254,gitlab.dev.apps.cs.sgp.dbs.com,bitbucket.sgp.dbs.com

git_bb_inventories=https://$pdcifgitchkout@bitbucket.sgp.dbs.com:8443/dcifgit/scm/ada/ada-inventories.git

# Checkout the cstaws-inventories source control and commit the changes
mkdir -p "terraform/terraform.tfstate.d"
cd "terraform/terraform.tfstate.d" || exit 1
if [ -d ".git" ]; then
  git reset --hard
  git pull $git_bb_inventories "$aws_accnt" 
else
  echo "Cloning the inventories $PWD"
  git clone -b "$aws_accnt" $git_bb_inventories .
fi
cd ..

_tfstatedir=terraform.tfstate.d/ADA-$adastack
if [ ! -d "$_tfstatedir" ]; then
  terraform workspace new ADA-${adastack}
else
  terraform workspace select ADA-${adastack}
fi

terraform init

echo "aws_accnt $aws_accnt"
aws_accnt="${aws_accnt:-dev6}"
echo "aws_accnt after default $aws_accnt $PWD"
build_vars="build-${JOB_BASE_NAME:-ada_create}-${aws_accnt:-dev6}-${adastack}.tfvars"
accnt_vars="$aws_accnt.tfvars"

if [ -z "$ami" ] || [ "default" = "$ami" ]; then
  if [ "$aws_accnt" = "dev6" ]; then
    # ami="ami-a65802da" # UAT_ENCRYPTED_DBSSTD_IMAGE_RHEL_7.4_V4
    ami="ami-b9237ac5" # UAT_UNENCRYPTED_DBSSTD_IMAGE_RHEL_7.4_V4
  elif [ "$aws_accnt" = "uatdatascience" ]; then
    # ami="ami-0e6055b8f1518e076" # UAT_UNENCRYPTED_DBSSTD_IMAGE_RHEL_7,4_V4
    ami="ami-0a6dab5fa44e059e6" # ami-uatds-sg-s-pcld-dbsstd-rhel-7.4-v4
  elif [ "$aws_accnt" = "proddatascience" ]; then
    ami="ami-05f9263524662f265" # ami-prdds-sg-s-pcld-dbsstd-rhel-7.4-v4
  else
    echo "ERROR! Please find the ami for the AWS account $aws_accnt"
    exit 1
  fi
fi

cat > "$build_vars" <<EOF
# BUILD_USER: $BUILD_USER
# BUILD_NUMBER: $BUILD_NUMBER
"adastack"="$adastack"
"one_bankid"="${BUILD_USER:-jenkins}"
"instance_type"="${instance_type:-t2.xlarge}"
"master_count"="${master_count:-2}"
"worker_count"="${worker_count:-1}"
"gateway_count"="${gateway_count:-1}"
"gateway_instance_type"="${gateway_instance_type:-$instance_type}"
"tac_count"="${tac_count:-0}"
"tjs_count"="${tjs_count:-0}"
"app_code"="${app_code:-ADA}"
"pc_code"="${pc_code:-0704}"
"ami"="$ami"
"key_name"="ada-node-${aws_accnt:-dev6}"
"accnt_name"="${aws_accnt:-dev6}"
"db_instance_type"="$db_instance_type"
"db_allocated_storage"="${db_allocated_storage:-100}"
"root_block_master_device_size"="${root_block_master_device_size:-$root_block_device_size}"
"root_block_worker_device_size"="${root_block_worker_device_size:-$root_block_device_size}"
"root_block_gateway_device_size"="${root_block_gateway_device_size:-$root_block_device_size}"
EOF


if [ "$destroy_first" = "true" ] || [ "$destroy_only" = "true" ]; then
  terraform destroy -force \
	  -var-file="$build_vars" -var-file="$accnt_vars"
fi

if [ "$destroy_only" = "true" ]; then
	terraform destroy -force \
	  -var-file="$build_vars" -var-file="$accnt_vars"

  destroyed="$?"

  cd "terraform.tfstate.d"

  # TODO: what is the pcf-operator email?
  git config user.email "@pcf-operator"
  git config user.name "PCF Operator"

  msg="Incomplete destroy of"

  [ "$destroyed" = "0" ] && rm -rf "$_tfstatedir" && msg="Remove the destroyed"

  git commit -a -m "$msg ADA-${adastack} inventory"
  git push "$git_bb_inventories" "$aws_accnt"

  exit 0
fi

terraform plan \
	  -var-file="$build_vars" -var-file="$accnt_vars"

[ "$debug_tf" = "true" ] && export TF_LOG=DEBUG
terraform apply -auto-approve \
	  -var-file="$build_vars" -var-file="$accnt_vars"

############# Inventory

echo "Starting the work on the inventory $_current_dir"
pwd
ls -la

cd "$_current_dir"

inventory_home="terraform/terraform.tfstate.d/ADA-${adastack}"

# Brutally remove what is in the repo and reset with the new state:
# export _tfstatedir="terraform/terraform.tfstate.d/ADA-${adastack}"
# [ -d "${inventory_home}" ] && rm -rf "${inventory_home}"

if [ "$destroy_only" != "true" ]; then

  cp "terraform/$build_vars" "${inventory_home}"
  cp "terraform/$accnt_vars" "${inventory_home}"
  # rm "${inventory_home}"/*.backup || true

  # Generate the ansible inventory with our small utility
  python terraform/ansible_inventory_maker.py "${inventory_home}/terraform.tfstate" "${adastack}" > "${inventory_home}/ADA-${adastack}.inventory"

if [ "$aws_accnt" == "uatdatascience" ]; then
  key_file=ada-node-uatdatascience.pem
elif [ "$aws_accnt" == "dev6" ]; then
  key_file=ada-node-dev6.pem
elif [ "$aws_accnt" == "prod6" ]; then
  key_file=ada-node-dev6.pem
fi

  cat << EOF > ${inventory_home}/extras.json
{
  "ansible_user": "ec2-user",
  "ansible_ssh_private_key_file": "\$HOME/.ssh/$key_file"
}
EOF

  python terraform/upsert_reverse_dns.py "${inventory_home}/terraform.tfstate"

fi

cd "terraform/terraform.tfstate.d"

# TODO: what is the pcf-operator email?
git config user.email "@pcf-operator"
git config user.name "PCF Operator"

git add -A
git commit -a -m "Update the ADA-${adastack} inventory"
git push "$git_bb_inventories" "$aws_accnt"
