#!/bin/bash
export https_proxy=http://proxy.sin.services.nonprod.c0.dbs.com:3128
export no_proxy=169.254.169.254,bitbucket.sgp.dbs.com

rm -rf inv
mkdir -p inv
cd inv
bb_ada_inv=https://$pdcifgitchkout@bitbucket.sgp.dbs.com:8443/dcifgit/scm/ada/ada-inventories.git
git clone -b uatdatascience "$bb_ada_inv" 

cp $WORKSPACE/inv/ada-inventories/ADA-infra/* $WORKSPACE/terraform/aws_vault_setup/

if [ -z "$ami" ] || [ "default" = "$ami" ]; then
  if [ "$aws_accnt" = "dev6" ]; then
    # ami="ami-a65802da" # UAT_ENCRYPTED_DBSSTD_IMAGE_RHEL_7.4_V4
    ami="ami-b9237ac5" # UAT_UNENCRYPTED_DBSSTD_IMAGE_RHEL_7.4_V4
  elif [ "$aws_accnt" = "uatdatascience" ]; then
    ami="ami-0e6055b8f1518e076" # UAT_UNENCRYPTED_DBSSTD_IMAGE_RHEL_7,4_V4
  else
    echo "ERROR! Please find the ami for the AWS account $aws_accnt"
    exit 1
  fi
fi

cd $WORKSPACE/terraform/aws_vault_setup/

aws_accnt="${aws_accnt:-dev6}"
echo "aws_accnt after default $aws_accnt $PWD"
build_vars="build-${JOB_BASE_NAME:-ada_create}-${aws_accnt:-dev6}-${adastack}.tfvars"
accnt_vars="$WORKSPACE/terraform/$aws_accnt.tfvars"

cat > "$build_vars" <<EOF
# BUILD_USER: $BUILD_USER
# BUILD_NUMBER: $BUILD_NUMBER
"one_bankid"="${BUILD_USER:-jenkins}"
"app_code"="${app_code:-ADA}"
"pc_code"="${pc_code:-0704}"
"ami"="$ami"
"key_name"="ada-node-${aws_accnt:-dev6}"
"accnt_name"="${aws_accnt:-dev6}"
EOF

if [ "$destroy" = "yes" ]; then
  terraform init
  terraform destroy -force \
	  -var-file="$build_vars" -var-file="$accnt_vars"
  echo "[vault_servers]" > ADA-infra.inventory
fi

if [ "$destroy_only" = "yes" ]; then
  cd $WORKSPACE/inv/ada-inventories
  git config --global push.default simple
  git config user.email "@pdcifgitchkout"
  git config user.name "pdcifgitchkout"
  git add -A
  git commit -m "removing ada-infra - vault"
  git push origin $branch
  exit
fi

terraform init
terraform plan
terraform apply -auto-approve
cp terraform* $WORKSPACE/inv/ada-inventories/ADA-infra/
echo "[vault_servers]" > ADA-infra.inventory
cat terraform.tfstate | grep fqdn | awk '{ print$2 }' | sed s/\"//g | sed  s/\,//g >> ADA-infra.inventory 

cd $WORKSPACE/inv/ada-inventories
git config --global push.default simple
git config user.email "@pdcifgitchkout"
git config user.name "pdcifgitchkout"
git add -A
git commit -m "updating ada-infra for vault"
git push origin $branch

cd $WORKSPACE

if [ "$init_vault" = "yes" ]; then
  ansible-playbook -i $WORKSPACE/inv/ada-inventories/ADA-infra/ADA-infra.inventory \
    --key-file "$HOME/.ssh/ada-node-${aws_accnt}.pem" install_vault.yml \
    -u ec2-user -e "@group_vars/cloud_${aws_accnt}" -e "vault_init='yes'" -v
else
  ansible-playbook -i $WORKSPACE/inv/ada-inventories/ADA-infra/ADA-infra.inventory \
    --key-file "$HOME/.ssh/ada-node-${aws_accnt}.pem" install_vault.yml \
    -u ec2-user -e "@group_vars/cloud_${aws_accnt}" -v
fi
