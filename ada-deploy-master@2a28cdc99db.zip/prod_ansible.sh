#!/bin/bash
_ENV=prod ./inventories/_ansible.sh "$@"
