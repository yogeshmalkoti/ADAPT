# ADA Deploy

Ansible Playbook to deploy ADA.

# Usage on cstaws:

- Create an inventory on cstaws: https://jenkins.ci.cstaws.dbs.com/job/create-ada-inventory
- Deploy on that inventory: https://jenkins.ci.cstaws.dbs.com/job/deploy-ada

# Usage on DEV:
ssh into x01badaapp1a.vsi.uat.dbs.com

```bash
git clone https://gitlab.dev.apps.cs.sgp.dbs.com/ada/ada-deploy
git clone https://gitlab.dev.apps.cs.sgp.dbs.com/ada/
```

# Status
CDH with standalone database.
Services are not assigned.

# Development

* Setup an [Ansible Control Machine](http://docs.ansible.com/ansible/intro_installation.html) 
* Create Ansible configuration (optional):

```ini
$ vi ~/.ansible.cfg

[defaults]
# disable key check if host is not initially in 'known_hosts'
host_key_checking = False

[ssh_connection]
# if True, make ansible use scp if the connection type is ssh (default is sftp)
scp_if_ssh = True
```

* Setup the extra variables json file:

.onprem_dev.json:

```json
{
  "_http_proxy": "http://abc:xyz@bcproxy.sgp.dbs.com:8080:8080",
  "ansible_user": "def",
  "ansible_ssh_pass": "tuv"
}
```

* Call the playbook:
```bash
ansible-playbook -i inventory_dev -e @.onprem_dev.json site.yml
```

On cstaws: https://jenkins.ci.cstaws.dbs.com/job/deploy-ada

* Create [Inventory](http://docs.ansible.com/ansible/intro_inventory.html) of cluster hosts:
    
* Run playbook
 
```shell
$ ansible-playbook -i ~/ansible_hosts site.yml
    
-i INVENTORY
   inventory host path or comma separated host list (default=/etc/ansible/hosts)
```

Ansible communicates with the hosts defined in the inventory over SSH. It assumes you’re using SSH keys to authenticate so your public SSH key should exist in ``authorized_keys`` on those hosts. Your user will need sudo privileges to install the required packages.

By default Ansible will connect to the remote hosts using the current user (as SSH would). To override the remote user name you can specify the ``--user`` option in the command, or add the following variables to the inventory:

```ini
[all:vars]
ansible_user=ec2-user
```

AWS users can use Ansible’s ``--private-key`` option to authenticate using a PEM file instead of SSH keys.

# Enabling Kerberos

The playbook can install a local MIT KDC and configure Hadoop Security. To enable Hadoop Security:

* Specify the '[krb5_server]' host in the inventory (see above)
* Set 'krb5_kdc_type' to 'mit' in ``group_vars/krb5_server.yml``

# Overriding CDH service/role configuration

The playbook uses [Cloudera Manager Templates](https://www.cloudera.com/documentation/enterprise/latest/topics/install_cluster_template.html) to provision a cluster.
As part of the template import process Cloudera Manager applies [Autoconfiguration](https://www.cloudera.com/documentation/enterprise/latest/topics/cm_mc_autoconfig.html)
rules that set properties such as memory and CPU allocations for various roles.

If the cluster has different hardware or operational requirements then you can override these properties in ``group_vars/cdh_servers``. 
For example:

```
cdh_services:
  - type: hdfs        
    datanode_java_heapsize: 10737418240
```

These properties get added as variables to the rendered template's instantiator block and can be referenced from the service configs.
For example ``roles/cdh/templates/hdfs.j2``:

```json
"roleType": "DATANODE",
"configs": [{
  "name": "datanode_java_heapsize",
  "variable": "DATANODE_JAVA_HEAPSIZE"
}
```

# How to contribute

* Fork the repo and create a topic branch
* Push commits to your repo
* Create a pull request!

# Vault setup of LDAP

```bash
# Use a functional ID to be able login and then search
unravel_fct_id_lan_id=DMSDKYL
vault write auth/ldap/config \
    url="ldaps://reg1.1bank.dbs.com:636" \
    userattr=sAMAccountName \
    userdn="ou=sg,ou=nds,dc=reg1,dc=1bank,dc=dbs,dc=com" \
    groupdn="ou=apps,dc=reg1,dc=1bank,dc=dbs,dc=com" \
    binddn="cn=$unravel_fct_id,ou=sg,ou=nds,dc=reg1,dc=1bank,dc=dbs,dc=com" \
    bindpass="$unravel_fct_id_pass" \
    insecure_tls=true \
    starttls=false

```
