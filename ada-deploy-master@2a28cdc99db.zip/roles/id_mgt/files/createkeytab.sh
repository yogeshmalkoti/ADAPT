#!/bin/bash

#########################################################################################################
#													#
# Example to use $sh createkeytab.sh username DOMAIN.DBS.COM password ###                            	#
# Example for 3 part user principal $sh createkeytab.sh username DOMAIN.DBS.COM password 3rd_part    	# 
#													#
#########################################################################################################

USER=$1
DOMAIN=$2
PASSWD=$3

# In some cases the principal name is alluxio/uat instead of alluxio
if [ -n "$4" ]; then
  PRINCN="$USER/$4"
else
  PRINCN="$USER"
fi

mkdir -p keytabs
ENC_TYPES="rc4-hmac aes256-cts"
PRINC="$PRINCN@$DOMAIN"
SLEEP=1
KEYTAB_OUT="$USER".keytab

# no need to regenerate the keytabs
[ -d "keytabs/$KEYTAB_OUT" ] && exit 0

IFS=' ' read -a ENC_ARR <<< "$ENC_TYPES"
{
  for ENC in "${ENC_ARR[@]}"
  do
    echo "addent -password -p $PRINC -k 1 -e $ENC"
    if [ $SLEEP -eq 1 ]; then
      sleep 1
    fi
    echo "$PASSWD"
  done
  echo "wkt keytabs/$KEYTAB_OUT"
} | /usr/bin/ktutil
chmod 600 keytabs/$KEYTAB_OUT
