Variety of shared documents and scripts - to be refined
=======================================================

Notes accumulated during the setup of the Jenkins slave, the chat server (Mattermost) and other one-shot.
Some automation eventually.
## Playbook to Setup NTP Master on AWS ####
To run this in AWS

[ For AWS only]

export http_proxy=http://proxy.cstaws.dbs.com:3128
export https_proxy=http://proxy.cstaws.dbs.com:3128

ansible-playbook aws_site.yml --private-key=~/test.pem -e "keypair=cst-datalake-devops-poc"

[For On-prem]
ansible-playbook -i inventory_onprem.yml -c paramiko -k onprem_site.yml

This playbook will create a file inventory.txt which contains the instance id and the private ip address.
