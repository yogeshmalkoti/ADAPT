#!/bin/bash
scriptloc=`pwd`
export ans_home=`dirname $scriptloc` 
echo $ans_home >>variable

