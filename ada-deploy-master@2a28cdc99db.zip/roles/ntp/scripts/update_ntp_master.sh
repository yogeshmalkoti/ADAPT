#!/bin/bash
# As soon as a master has been elected, reconfigure the client to point to the master
# 
#./getpwd.sh
ans_home='/home/centos/ntp'
cd "$ans_home"/roles
cp client/files/ntp_client.conf.j2 client/templates/ntp_client.conf.j2

# grab all the masters and insert them in the config file
awk '{print $NF}' master/files/inventory_master.txt | xargs -n1 -I {} sed -i "/HERE_WE_WILL_INSERT_THE_MASTERS/a server {} " client/templates/ntp_client.conf.j2

