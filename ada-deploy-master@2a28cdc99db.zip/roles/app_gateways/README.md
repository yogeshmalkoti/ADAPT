### Execution Steps #####

ansible-playbook -i hosts.yml --key-file=id_rsa_2048_a_adauser1_x01sadaapp1a_shared.pem  -c paramiko site.yml

