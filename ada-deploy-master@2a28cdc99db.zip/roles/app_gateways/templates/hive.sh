#!/bin/bash
### Need to check for the keytab and principal to use ####

kinit -kt /home/adauser1/keys/hue.keytab hue/`hostname`@SVCSUAT.DBS.COM
beeline -u "jdbc:hive2://{{ hiveserver }}:10000/default;ssl=true;sslTrustStore=/tmp/cacerts;trustStorePassword=changeit;principal=hive/_HOST@SVCSUAT.DBS.COM" -f /tmp/hive.hql
