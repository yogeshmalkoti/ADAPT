#!/bin/bash
CDH_DATA_DRIVE_PATH=${CDH_DATA_DRIVE_PATH:-/data}

accnt_name=${accnt_name:-dev6}
accnt_domain=${accnt_domain:-$accnt_name.nonprod.c0.dbs.com}

function cleanup_director {
  service cloudera-director-server stop
  yum remove cloudera-director-server -y
  yum remove cloudera-director-client -y
  mv /var/lib/cloudera-director-server /var/lib/cloudera-director-server.bak.$(date +"%y%m%d%T")
  mv /etc/cloudera-director-server /etc/cloudera-director-server.bak.$(date +"%y%m%d%T")
  mv ~/.cloudera-director ~/.cloudera-director.bak..$(date +"%y%m%d%T")
  yum reinstall cloudera-director-plugins -y
}
function remove_manager {
  echo "Cleaning up Cloudera Manager ..."
  # Unintall Cloudera Manager
  service cloudera-scm-server stop
  service cloudera-scm-server-db stop
  yum remove cloudera-manager-server -y
  yum remove cloudera-manager-server-db-2 -y
  #rm -rf /etc/cloudera-scm-server/
  rm -rf /opt/cloudera/parcels/*
  rm -rf /var/lib/cloudera-scm-server/
}
function remove_agent {
  echo "Cleaning up Cloudera Agent ..."
  # Uninstall Agent
  service cloudera-scm-agent next_stop_hard
  service cloudera-scm-agent stop
  # Kill agent and its processes
  sh -c "ps ax | grep \"bin\/supervisor\" | sed -e 's/^[[:space:]]*//' | cut -d \" \" -f 1 | xargs kill -9"
  sh -c "ps ax | grep \"bin\/cmf-agent\" | sed -e 's/^[[:space:]]*//' | cut -d \" \" -f 1 | xargs kill -9"
  sh -c "ps ax | grep \"bin\/cmf-listener\" | sed -e 's/^[[:space:]]*//' | cut -d \" \" -f 1 | xargs kill -9"
  sh -c "ps ax | grep \"bin\/flood\" | sed -e 's/^[[:space:]]*//' | cut -d \" \" -f 1 | xargs kill -9"
  yum remove 'cloudera-manager-*' -y
  # Clean Cloudera Manager/Agent processes and data
  for u in cloudera-scm flume hadoop hdfs hbase hive httpfs hue impala llama mapred oozie solr spark sqoop sqoop2 yarn zookeeper; do kill $(ps -u $u -o pid=); done
  umount cm_processes
  rm -Rf /usr/share/cmf /var/lib/cloudera* /var/cache/yum/cloudera* /var/log/cloudera* /var/log/hbase* /var/log/hadoop* /var/log/hive* /var/log/oozie* /var/log/zookeeper* /var/log/flum* /varlog/spark* /var/log/sentry* /run/cloudera-scm-agent /var/run/cloudera* /opt/cloudera/parcels/
  rm -f /tmp/.scm_prepare_node.lock
  # Clean Up User Data
  rm -Rf /var/lib/flume-ng /var/lib/hadoop* /var/lib/hue /var/lib/navigator /var/lib/oozie /var/lib/solr /var/lib/sqoop* /var/lib/zookeeper
  rm -Rf /dfs /nn /dn /mapred /yarn /data/dfs /data/nn /data/dn /data/mapred /data/yarn
  #-E rm -rf /etc/cloudera-scm-agent/
  rm -rf /var/lib/cloudera-scm-agent/
  rm -rf /var/tmp/impala* /var/tmp/oozie*
  ls -l /etc/alternatives/ | grep -E "\/opt\/cloudera|\/etc" | awk {'print $9'} | while read m; do if [[ -e /var/lib/alternatives/${m} ]]; then rm -f /var/lib/alternatives/${m}; fi; rm -f /etc/alternatives/${m}; done
  rm -rf /etc/__cloudera_generation__  /etc/__cloudera_metadata__ /etc/cloudera-scm-agent /etc/flume-ng /etc/hadoop* /etc/hbase* /etc/hive* /etc/hue* /etc/impala* /etc/sentry /etc/spark* /etc/sqoop* /etc/zookeeper
}
remove_manager
remove_agent
[ -e /var/lib/cloudera-director-server ] && cleanup_director