import subprocess
import sys

##0 : means success
##1 : means failure

def run_cmd(args_list):
	retcode=0
	print('Running system command: {0}'.format(' '.join(args_list)))
	proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
	(output, errors) = proc.communicate()
	if proc.returncode:
		print ("Error Code is %s", proc.returncode)
		#raise RuntimeError('Error running command: %s. Return code: %d, Error: %s' % (' '.join(args_list), proc.returncode, errors))
		retcode=proc.returncode
		print (output,errors)
	return retcode

print ("-----------------")
retcode = run_cmd([sys.argv[1], sys.argv[2]])
print ("return code is",retcode)
sys.exit(retcode)

