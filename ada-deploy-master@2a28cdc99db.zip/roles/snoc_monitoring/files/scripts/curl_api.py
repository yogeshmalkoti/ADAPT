#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import string
try:
	import pycurl2 as pycurl
except:
	import pycurl

import urllib
import StringIO
import socket

client_url = sys.argv[1]

def body_write(buf):
	sys.stdout.write(buf)

def write_null(buf):
	pass

# normal init  
def curl_init(curl):
	curl.setopt(curl.NOSIGNAL, 1)
	curl.setopt(curl.NOPROGRESS, 1)
	curl.setopt(curl.SSL_VERIFYPEER, 0)
	curl.setopt(curl.SSL_VERIFYHOST, 0)
	curl.setopt(curl.TIMEOUT, 300)
	curl.setopt(curl.AUTOREFERER, 1)
	curl.setopt(curl.COOKIEFILE, '')
	curl.setopt(curl.COOKIELIST, 'ALL')

	curl.setopt(curl.FOLLOWLOCATION, 0)

	curl.fp = StringIO.StringIO()
	curl.setopt(curl.WRITEFUNCTION, write_null) 

	curl.setopt(curl.VERBOSE, 0)

# set cookie	
def set_cookie(curl, cookie):
	curl.setopt(curl.COOKIE, cookie)

def check_status(curl, code):
	ret = curl.getinfo(curl.RESPONSE_CODE)
	if code != ret:
		print ("url [%s] return code is : %d" % (curl.getinfo(curl.EFFECTIVE_URL), ret))
		return -1
	return 0

def parse_arg(data, s, t):
	start = data.find(s)
	if -1 == start:
		return None

	start = start + len(s)

	data = data[start:]
	end = data.find(t)
	if -1 == end:
		return None

	return data[0: end]

if __name__ == '__main__':
	ret_code=0

	# global init
	pycurl.global_init(pycurl.GLOBAL_ALL) 
	curl = pycurl.Curl()

	# curl object init
	curl_init(curl)

	# auth mode
	# set_cookie(curl, V2EX_COOKIE)
	
	# broser index for some cookie
	curl.setopt(curl.WRITEFUNCTION, write_null)
	curl.setopt(curl.URL, client_url)
	try:
		curl.perform()
	except Exception as v:
		errorcode=v
		print ("Connection Refused")
	finally:
		ret_code=check_status(curl, 200)

	# HTTP code must be 200
	if -1 == ret_code:
		print ('Something wrong...')


	# clean curl
	curl.close()
	pycurl.global_cleanup() 
	print ("-----------",ret_code)
	sys.exit(ret_code)