import sys
import pandas as pd

json_file = pd.read_json(sys.argv[1])
json_file.to_csv()