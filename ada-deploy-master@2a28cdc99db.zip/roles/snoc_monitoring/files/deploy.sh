#!/bin/bash

if [ -z "$adastack" ]; then
    # Nothing to do
    exit 0
fi

WORKSPACE=${WORKSPACE:-$PWD}

export adaacnt=$1
export adastack=$2
export user_keytab=$3
export user_princ=$4
export namenode=$5
export cm_host=$6
export cm_user_pwd=$7
export cm_cluster_name=$8
export airflow_master=$9
export airflow_workers=${10}
export rm_host1=${11}
export rm_host2=${12}
export hive_host=${13}
export hive_princ=${14}
export zookeeper=${15}
export spark_hist_url=${16}
export spark2_hist_url=${17}
export spark_home=${18}
export es_host_ip=${19}

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [[ "$NODE_LABELS" = *AWS* ]]; then
    if [[ "$NODE_LABELS" = *DEV* ]]; then
        export aws_accnt=dev6
    else
        export aws_accnt=""
    fi
else
    export ADA_USER=${ADA_USER:-adauser1}
    echo "WARN: please setup extra env variable for on-premise"
    exit 1
fi

cat <<EOF > $WORKSPACE/mon_vars.json
{
    "USER_KEYTAB": "${user_keytab}",
    "USER_PRINC": "${user_princ}",
    "NAMENODE": "${namenode}",
    "CM_HOST": "${cm_host}",
    "CM_USER_PWD": "${cm_user_pwd}",
    "CM_CLUSTER_NAME": "${cm_cluster_name}",
    "AIRFLOW_MASTER": "${airflow_master}",
    "AIRFLOW_WORKERS": "${airflow_workers}",
    "RM_HOST1": "${rm_host1}",
    "RM_HOST2": "${rm_host2}",
    "HIVE_HOST": "${hive_host}",            
    "HIVE_PRINC": "${hive_princ}",     
    "ZK_SERVER": "${zookeeper}",     
    "SPARK_HIST_URL": "${spark_hist_url}",     
    "SPARK2_HIST_URL": "${spark2_hist_url}",     
    "SPARK_HOME": "${spark_home}",     
    "ES_HOST_IP": "${es_host_ip}"     
}
EOF

inventory_file=$WORKSPACE/ada-inventories/ADA-$adastack/ADA-$adastack.inventory
ansible-playbook $ansible_verbosity -i "$inventory_file" \
 --key-file "$HOME/.ssh/ada-node-$aws_accnt.pem" \
 -e @$WORKSPACE/mon_vars.json site_snoc.yml



  
