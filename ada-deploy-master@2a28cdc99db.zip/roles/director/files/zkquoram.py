import sys
def get_zookeeper_server_count(director_conf_file):
    result = {}
    with open(director_conf_file, 'r') as config:
        lines = config.readlines()
        count=0
        for line in lines:
            line = line.strip()
            zkeeper = False
            if line.startswith("count"):
                try:
                    server_count = line.split(":")[1]
                    count += 1
                    result["Server-" + str(count) ] = [server_count.strip(), False]
                except:
                    continue

            if line.startswith("ZOOKEEPER"):
                try:
                    idle_split = line.split(":")[1]
                    result["Server-" + str(count) ] = [server_count.strip(), True]
                except:
                    continue
    return result

def generate_zookeeper_quoram(dict_zk, stack_name, zk_port):
    zkquoram = ""
    count = 0
    for k,v in dict_zk.items():
        if v[1] == True:
            for i in range(int(v[0])): #ada-sa7-master-0.cstaws.dbs.com ada-san-wk0.dev6.nonprod.c0.dbs.com
                zkquoram += "ada-" + stack_name + "-wk" + str(count) + ".dev6.nonprod.c0.dbs.com:" + str(zk_port) + ","
                count+=1
        else:
            try:
                count += int(v[0])
            except ValueError:
                continue;
    return zkquoram[:-1]

stack= sys.argv[1]
conf_file= sys.argv[2]
zk_port = sys.argv[3]
def zookeeper_quoram(stack, conf_file, zk_port):
    result = get_zookeeper_server_count(conf_file)
    zk_quoram = generate_zookeeper_quoram(result, stack, zk_port)
    return zk_quoram
print(zookeeper_quoram(stack, conf_file, zk_port) )
