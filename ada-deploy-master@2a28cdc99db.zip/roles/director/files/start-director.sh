#!/bin/bash
echo "lp.plugin.configuration.blacklist: sandbox" >> /etc/cloudera-director-server/application.properties

# Sometimes the cleanup script cleaned a lot of things but reinstall did not happen:
if [ ! -d /var/log/cloudera-director-server ]; then
  yum reinstall cloudera-director-server -y
fi
if [ ! -d /var/lib/cloudera-director-plugins ]; then
  yum reinstall cloudera-director-plugins -y
fi

service cloudera-director-server start
sleep 5
until service cloudera-director-server status; do
  echo "cloudera-director-server is not starting. Try to restart service in 5 sec...."
  service cloudera-director-server restart
  sleep 5
done
DIRECTOR_URL="http://localhost:7189"
until curl -m 15 $DIRECTOR_URL &> /dev/null; do echo "Waiting for director to be ready..."; done
echo "Director is ready!"
