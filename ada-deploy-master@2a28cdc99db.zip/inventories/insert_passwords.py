# Load the passwords from a file into an array.
# Reads the lines of the inventory one by one
# When the line declares a host regenerate the line with the ansible_become_pass filled in
#
# Also replaces the $HOME environment variable
#

# The _ENV env variable must be uat/prod/legacydev

import os
import re
import string
import sys

home = os.environ.get('HOME')
_env = os.environ.get('_ENV')
dir_path = os.path.dirname(os.path.realpath(__file__))

# On-prem the pem file is found in ~/.ssh2
# this will magically detect the $HOME/.ssh and replace it by $HOME/.ssh2
dot_ssh = home + "/.ssh/"
replace_dot_ssh = home + "/.ssh/"
if os.path.isdir(home + "/.ssh2/") and not os.path.isdir(home + "/.ssh/"):
  replace_dot_ssh = home + "/.ssh2/"

passwords_file = open(dir_path + '/' + _env + '.passwords', 'r')
passwords = passwords_file.read().splitlines()

uat_sgp = "uat"
host_prefix="x01sadaapp"
if _env.startswith('dev'):
  host_prefix="x01badaapp"
elif _env == 'prod':
  host_prefix="x01gadaapp"
  uat_sgp = "sgp"

inventory_file = open(dir_path + '/' + _env + '.inventory', 'r')
inventory = inventory_file.read().splitlines()

for num, line in enumerate(inventory, start=1):
  # x01sadaapp11a.vsi.uat.dbs.com ansible_become_pass=123
  # x01badaapp10a...
  # x[\d\d]
  r = re.search("^" + host_prefix + "([\\d]*)a.vsi." + uat_sgp + ".dbs.com ansible_become_pass=", line)
  if r:
    host = host_prefix+r.group(1)+"a.vsi." + uat_sgp + ".dbs.com"
    index = int(r.group(1))-1
    if len(passwords) > index:
      password = " ansible_become_pass=\""+passwords[index]+"\""
    else:
      sys.stderr.write("WARN: No password for " + host + "\n")
      password = ""
    print host + password  # pylint: disable=E1601
  else:
    line = string.replace(line, '$HOME', home)
    print string.replace(line, dot_ssh, replace_dot_ssh) # pylint: disable=E1601

