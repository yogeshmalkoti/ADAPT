#!/bin/bash
# Runs ansible-playbook or ansible ad-hoc
# Called with _ENV=dev|uat|legacydev
#if [[ "$*" =~ -h ]]; then
#echo "
#Adhoc command for "${_ENV}":
#
#  ./${_ENV}_ansible.sh scm_server -a 'ls -ltr'
#
#Run playbook on UAT on a single host:
#  ./${_ENV}_ansible.sh --tags yum_repos --limit x01sadaapp30a.vsi.uat.dbs.com site.yml
#
#Setup for UAT:
#- Make sure the shared pem file for uat is in $HOME/.ssh/uat.pem
#- Keep the inventories/uat.passwords file up to date with the root passwords for each machine
#"
#exit 0
#fi
if [ ! -f inventories/${_ENV}.passwords ]; then
  echo "ERROR: Please enter the list of root passwords into the file inventories/${_ENV}.passwords"
  exit 1
fi
python inventories/insert_passwords.py > inventories/"${_ENV}".inventory_with_passwords
if [[ "$*" =~ -a\  ]]; then
 ansible -i inventories/"${_ENV}".inventory_with_passwords "$@"
else
 ansible-playbook -i inventories/"${_ENV}".inventory_with_passwords "$@"
fi
