# Extract the inventory straight from terraform state
# Make a map of the IP address, by role and by fqdn.
# Then generate the inventory by template
# {
#   modules: [
#     {  path: [ "root" ]
#        resources: {
#           aws_db_instance.default: {
#                primary: { attributes: {
#                  "address": "terraform-20180320123934001000000001.chycoxkpf8ex.ap-southeast-1.rds.amazonaws.com",
#                  "endpoint": "terraform-20180320123934001000000001.chycoxkpf8ex.ap-southeast-1.rds.amazonaws.com:3306"
#                } }
#           }
#           aws_route53_record.scm: {
#                primary: { attributes: {
#                    fqdn: "ada-ci-scm.cstaws.dbs.com",
#                    "records.2186012537": "10.115.80.227",
#                } }
#           }
#        }
#     },
#     {  path: [ "root", "scm" ]
#        resources: {
#           aws_route53_record.adanodecname: {
#                primary: { attributes: {
#                    fqdn: "ada-ci-scm-0.cstaws.dbs.com",
#                    "records.2186012537": "10.115.80.227",
#                } }
#           }
#     },
#     {  path: [ "root", "db" ]
#        resources: {
#           aws_route53_record.adanodecname: {
#                primary: { attributes: {
#                    fqdn: "ada-ci-db-0.cstaws.dbs.com",
#                    "records.2759570544": "10.115.80.242",
#                } }
#           }
#     },
#     {  path: [ "root", "worker" ]
#        resources: {
#           aws_route53_record.adanodecname.0: {
#                primary: { attributes: {
#                    fqdn: "ada-ci-worker-0.cstaws.dbs.com",
#                    "records.1007893704": "10.115.80.27",
#                } }
#           },
#           aws_route53_record.adanodecname.1: {
#                primary: { attributes: {
#                    fqdn: "ada-ci-worker-1.cstaws.dbs.com",
#                    "records.1733598084": "10.115.80.12",
#                } }
#           },
#           aws_route53_record.adanodecname.2: {
#                primary: { attributes: {
#                    fqdn: "ada-ci-worker-2.cstaws.dbs.com",
#                    "records.328430692": "10.115.80.192",
#                } }
#           },
#     },
#   ]
# }


import sys
import json
import io
import datetime
import re

src = sys.argv[1]
f = io.open(src, mode="r", encoding="utf-8")
loaded = json.loads(f.read())

# fqdn -> ip
fqdns_to_ip = {}
# ip -> fqdns
ips_to_fqdns = {}
# ip -> tags
ips_to_tags = {}
# role -> [ip]
role_to_ips = {}

aws_s3_bucket_adashared = ""

for module in loaded["modules"]:
  for res_name, res_value in module["resources"].iteritems():
    if res_name.startswith("aws_db_instance.hadoop"):
      attributes = res_value["primary"]["attributes"]
      rds_db_address = attributes['address']
      continue
    if res_name == "aws_s3_bucket.adashared":
      aws_s3_bucket_adashared = res_value["primary"]["id"]
      continue
    if len(module['path']) == 1:
      # Skip the top level one for everything else
      continue
    if res_name.startswith("aws_route53_record."):
      attributes = res_value["primary"]["attributes"]
      fqdn = attributes["fqdn"]
      if fqdn.endswith("arpa"): # or fqdn.startswith("cdsw-ada") or fqdn.startswith("*.cdsw-ada"):
        continue
      for attr_name, attr_value in attributes.iteritems():
        if attr_name.startswith("records.") and attr_name != "records.#":
          ip = attr_value
          fqdns_to_ip[fqdn] = ip
          if not ips_to_fqdns.has_key(ip):
            ips_to_fqdns[ip] = []
          ips_to_fqdns[ip].append(fqdn)
          break
    elif res_name.startswith("aws_instance."):
      attributes = res_value["primary"]["attributes"]
      private_ip = attributes['private_ip']
      tags = {}
      for attr_name, attr_value in attributes.iteritems():
        if attr_name.startswith("tags.") and attr_name != "tags.%":
          # "tags.Ada-stack": "ci",
          # "tags.App-code": "ADA",
          # "tags.Name": "ADA-ci",
          # "tags.Role": "db",
          tags[attr_name.split(".")[1]] = attr_value
      ips_to_tags[private_ip] = tags
      role = tags['Role']
      if not role_to_ips.has_key(role):
        role_to_ips[role] = []
      role_to_ips[role].append(private_ip)

# Extract the index of an fqdn
def get_index(fqdn):
  s = re.search("-([\\d]+).cstaws.dbs.com", fqdn)
  if s:
    return int(s.group(1))

# Get the fqdns of a role. Sorted by index
def get_fqdns(role):
  if role not in role_to_ips:
    return []
  ips = role_to_ips[role]
  fqdns = [ ips_to_fqdns[x] for x in ips ]
  # Flatten:
  return sorted([ item for sublist in fqdns for item in sublist ],
                key=lambda x: get_index(x))

scm = get_fqdns('scm')[0]
accnt_domain = '.'.join(scm.split('.')[1:])
accnt_name = accnt_domain.split('.')[0]

variables = {
  'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
  'role_director': scm, #'jenkins-director.cstaws.dbs.com',
  'role_scm': scm,
  'role_gateway': '\n'.join(get_fqdns('gateway')),
  'role_master': '\n'.join(get_fqdns('master')),
  'role_worker': '\n'.join(get_fqdns('worker')),
  'role_alluxio_masters': '\n'.join(get_fqdns('master')[0:3]),
  'role_alluxio_workers': '\n'.join(get_fqdns('worker')),
  'role_tac_servers': '\n'.join(get_fqdns('tac')),
  'role_tjs_servers': '\n'.join(get_fqdns('tjs')),
  'role_vault_servers': '\n'.join(get_fqdns('vault')),
  'all_hosts': '\n'.join(fqdn for (fqdn,ip) in sorted(fqdns_to_ip.items())),
  'ansible_user': 'ec2-user',
  'adastack': sys.argv[2],
  'rds_db_address': rds_db_address,
  'accnt_domain': accnt_domain,
  'accnt_name': accnt_name,
  'aws_s3_bucket_adashared': aws_s3_bucket_adashared
}

inventory = """
# {timestamp}
[cloud_{accnt_name}]
{all_hosts}

[director_server]
{role_director}

[scm_server]
{role_scm}

[utility_servers:children]
scm_server

[gateway_servers]
{role_gateway}
{role_tjs_servers}

[master_servers]
{role_master}

[worker_servers]
{role_worker}

[alluxio_masters]
{role_alluxio_masters}

[alluxio_workers]
{role_alluxio_workers}

[tac_servers]
{role_tac_servers}

[tjs_servers]
{role_tjs_servers}

[vault_servers]
{role_vault_servers}

#[worker_servers:vars]
#host_template=HostTemplate-Workers

[cdh_servers:children]
utility_servers
worker_servers

[all:vars]
ansible_user={ansible_user}
adastack={adastack}
rds_db_address={rds_db_address}
accnt_domain={accnt_domain}
accnt_name={accnt_name}
aws_s3_bucket_adashared={aws_s3_bucket_adashared}
""".format(**variables)

print inventory # pylint: disable=E1601
