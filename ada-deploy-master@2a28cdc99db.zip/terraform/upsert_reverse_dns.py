# Create the route53 records for the reverse DNS

import boto3
import json
import itertools
import sys
import io

src = sys.argv[1]
f = io.open(src, mode="r", encoding="utf-8")
loaded = json.loads(f.read())

# fqdn -> ip
fqdns_to_ip = {}

route53= boto3.client('route53')

def add_cname_record(hosted_zone, fqdn, ip_address):
  try:
    route53.change_resource_record_sets(
    HostedZoneId=hosted_zone['Id'].split('/')[-1],
    ChangeBatch= {
      'Comment': 'add %s -> %s' % (fqdn, ip_address),
      'Changes': [
        {
          'Action': 'UPSERT',
          'ResourceRecordSet': {
            'Name': '.'.join(reversed(ip_address.split('.'))) + '.in-addr.arpa.',
            'Type': 'PTR',
            'TTL': 300,
            'ResourceRecords': [{'Value': fqdn}]
        }
      }]
  })
  except Exception as e:
    print e


# Index the reverse lookup DNS zones
hosted_zones = route53.list_hosted_zones()['HostedZones']
hosted_zones_by_sub = {}
for hosted_zone in hosted_zones:
    name = hosted_zone['Name']
    if not name.endswith('.in-addr.arpa.'):
        continue
    # extracts 178.116.10
    sub = name[:-14]
    # Index the hosted zones by the normal lookup domain: 10.116.178
    hosted_zones_by_sub['.'.join(reversed(sub.split('.')))] = hosted_zone

# traverse the TF state where we have the dns records but not the reverse ones:
for module in loaded["modules"]:
  for res_name, res_value in module["resources"].iteritems():
    if res_name.startswith("aws_route53_record."):
      attributes = res_value["primary"]["attributes"]
      fqdn = attributes["fqdn"]
      if fqdn.endswith("arpa"):
        continue
      for attr_name, attr_value in attributes.iteritems():
        if attr_name.startswith("records.") and attr_name != "records.#":
          ip = attr_value
          # 178.116.10.123 -> 178.116.10
          sub = '.'.join(ip.split('.')[:-1])
          if sub in hosted_zones_by_sub:
            hosted_zone = hosted_zones_by_sub[sub]
          else:
            # We are in cstaws where there is a single zone for all of 10.0.0.0/8
            hosted_zone = hosted_zones_by_sub['10']
          add_cname_record(hosted_zone, fqdn, ip)
