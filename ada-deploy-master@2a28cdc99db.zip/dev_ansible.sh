#!/bin/bash
_ENV=dev ./inventories/_ansible.sh "$@"