#!/bin/bash

if [ -z "$adastack" ]; then
    # Nothing to do
    exit 0
fi

WORKSPACE=${WORKSPACE:-$PWD}

export adaacnt=$1
export adastack=$2

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [[ "$NODE_LABELS" = *AWS* ]]; then
    if [[ "$NODE_LABELS" = *DEV* ]]; then
        export aws_accnt=dev6
    else
        export aws_accnt=""
    fi
else
    export ADA_USER=${ADA_USER:-adauser1}
    echo "WARN: please setup extra env variable for on-premise"
    exit 1
fi

inventory_file=$WORKSPACE/ada-inventories/ADA-$adastack/ADA-$adastack.inventory
ansible-playbook $ansible_verbosity -i "$inventory_file" \
 --key-file "$HOME/.ssh/ada-node-$aws_accnt.pem" \
 ${WORKSPACE}/hive/ansible/hive_client.yml

  
