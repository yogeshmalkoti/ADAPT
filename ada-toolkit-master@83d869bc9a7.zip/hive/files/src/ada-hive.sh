#!/bin/bash
############################################################################
#   Program name: hive_wrapper.sh
#   Program type: Linux Shell script
#   Date        :
#   Description : This shell script will connect hive server

############################################################################

source `pwd`/hive_properties.conf

beeline -u "jdbc:hive2://$HIVE_SERVER:$HIVE_PORT/default;ssl=$SSL_VALUE;sslTrustStore=$SSL_CERT;trustStorePassword=$TRUST_PASSWORD;principal=$PRINCIPAL" $*
