## ADA Toolkit

This project includes scripts to build ADA Toolkit which will include *properly configured* spark, hive, and alluxio wrappers. This toolkit targets to provide an expressway for development teams to easily access different ADA Data Platforms (e.g. AWS DEVs and on-prem UAT etc) with minimum effort.

### ADA Spark Wrapper

#### Overview
Current approach is to build ADA Spark Wrapper based on Cloudera CDH Parcels and configurations, the benefits are:
- CDH already manages all the spark dependencies in their product. We could leverage on it without re-introduce another dependency management system.
- CDH already generats proper configuration files and dynamically manage them upon any cluster changes. We could leverage on this and rebuild the ADA upon cluster configuration changes.
- Leveraging the dependency management and config file generation to CDH, we can focus ourselves on more important things like security integration with AD/Vault, multi-environment management support, and other usability features.

#### Build ADA Spark
```
#Example: build for AWS 'dev6' account, for ADA cluster 'dev'
> cd <ada_toolkit_project>/spark/bin
> sh build.sh dev6 dev
```

#### Run ADA Spark
```
#Vault download your keytab
export VAULT_ADDR=https://vault.dev6.nonprod.c0.dbs.com
##Vault Login
curl -v -k --request POST --data '{"password":"<my_pass>"}' $VAULT_ADDR/v1/auth/ldap/login/<my1bankid>
export VAULT_TOKEN="0596ca86-8177-9768-83f1-f894f035b9e7"
##Vault List Function IDs
curl -v -k -H "X-Vault-Token: $VAULT_TOKEN" -X GET $VAULT_ADDR/v1/secret/1bankid/<my1bankid>
##Vault Display Base64 format FunctionID Keytab
curl -v -k -H "X-Vault-Token: $VAULT_TOKEN" -X GET $VAULT_ADDR/v1/secret/fctid/fctid1/keytab
##Save Keytab
echo "BASE64_KEYTAB_STRING" | base64 --decode > <myfunctionid>.keytab

#Kerberos Login
kinit -kt <my.keytab> <myfunctionid>@SVCSUAT.DBS.COM

#Run ADA Spark Shell
cd <ada-toolkit-dir>/bin
./ada-spark2-shell

#Run ADA Spark Submit Example
./ada-spark2-example

```

### ADA Hive Wrapper
U/C.

### ADA Alluxio Wrapper
U/C.
