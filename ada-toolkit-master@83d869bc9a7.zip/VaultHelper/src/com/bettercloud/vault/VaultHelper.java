package com.bettercloud.vault;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.io.FileUtils;

import com.bettercloud.vault.response.AuthResponse;
import com.bettercloud.vault.response.LogicalResponse;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

public class VaultHelper {
	public static void main(String[] args) throws ParseException, VaultException {
		Options options = new Options();
		
		options.addOption("a", "account", true, "account id");
		options.addOption("u", "url", true, "vault server url");
		options.addOption("t", true, "vault token");
		options.addOption("l", false, "login");
		options.addOption("f", false, "list functional IDs");
		options.addOption("k", true, "functional ID keytab to download");

		
		CommandLineParser parser = new DefaultParser();
		CommandLine cmd = parser.parse(options, args);
		
		if (cmd.hasOption("l")){
			getToken(cmd);
			System.exit(0);		
		} else if (cmd.hasOption("f")) {
			System.out.println("Fuctional IDs available for " + cmd.getOptionValue("a") + ": " + getFctids(cmd));
			System.exit(0);
		} else if (cmd.hasOption("k")) {
			byte[] decoded = getKeytab(cmd);
			try {
				FileUtils.writeByteArrayToFile(new File(cmd.getOptionValue("k") + ".keytab"), decoded);
			} catch (IOException e) {
				System.out.println("Error writing keytab file: " + e);
			}
		}	
	}
	
	public static byte[] getKeytab (CommandLine cmdline) {
		VaultConfig vaultConfig = null;
		try {
			vaultConfig = new VaultConfig().address(cmdline.getOptionValue("u")).token(cmdline.getOptionValue("t")).sslConfig(new SslConfig().verify(false).build()).build();
		} catch (VaultException e) {
			System.out.println("Error logging in to Vault server: " + e);
		}
		final Vault vault = new Vault(vaultConfig);
		LogicalResponse response = null;
		try {
			response = vault.withRetries(5,100).logical().read("secret/fctid/" + cmdline.getOptionValue("k") + "/keytab");
		} catch (VaultException e) {
			System.out.println("Error reading keytab data from Vault server: " + e);
		}
		String encoded = response.getData().get("keytab");
		System.out.println("keytab=" + encoded);
		byte[] decoded = Base64.getDecoder().decode(encoded);
		return decoded;
	}
	
	public static String getFctids (CommandLine cmdline) {
		VaultConfig vaultConfig = null;
		try {
			vaultConfig = new VaultConfig().address(cmdline.getOptionValue("u")).token(cmdline.getOptionValue("t")).sslConfig(new SslConfig().verify(false).build()).build();
		} catch (VaultException e) {
			System.out.println("Error logging in to Vault server: " + e);
		}
		final Vault vault = new Vault(vaultConfig);
		LogicalResponse response = null;
		try {
			response = vault.withRetries(5,100).logical().read("secret/1bankid/" + cmdline.getOptionValue("a"));
		} catch (VaultException e) {
			System.out.println("Error getting fctid list from Vault server: " + e);
		}
		return response.getData().get("fctids");
	}
	
	public static void getToken(CommandLine cmdline) {
		java.io.Console console = System.console();
		String password = new String(console.readPassword("Enter Account Password: "));
		VaultConfig vaultConfig = null;
		try {
			vaultConfig = new VaultConfig().address(cmdline.getOptionValue("u")).sslConfig(new SslConfig().verify(false).build()).build();
		} catch (VaultException e) {
			System.out.println("Error logging in to Vault server: " + e);
		}
		final Vault vault = new Vault(vaultConfig);
		AuthResponse response = null;
		try {
			response = vault.auth().loginByLDAP(cmdline.getOptionValue("a"), password);
		} catch (VaultException e) {
			System.out.println("Error getting token from Vault server: "+ e);
		}
		final String token = response.getAuthClientToken();
		System.out.println("Token generated for " + cmdline.getOptionValue("a") + " : " + token);
		System.out.println("Use this token get your list of accessible functional ids and download the keytabs individually");
	}
} 