export CLASSPATH=$(echo ./lib/alluxio-enterprise-*client*kms.jar | tr ' ' ':')

java -cp $CLASSPATH:ada-alluxio-client.jar AlluxioFS $*
