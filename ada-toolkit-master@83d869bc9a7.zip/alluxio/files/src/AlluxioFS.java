import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;

import alluxio.AlluxioURI;
import alluxio.client.file.FileInStream;
import alluxio.client.file.FileOutStream;
import alluxio.client.file.FileSystem;
import alluxio.client.file.options.DeleteOptions;
import alluxio.client.file.options.ListStatusOptions;
import alluxio.client.file.options.SetAttributeOptions;
import alluxio.exception.AlluxioException;
import alluxio.security.authorization.Mode;
import alluxio.security.authorization.Mode.Bits;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import alluxio.client.file.URIStatus;

class AlluxioOPS{

	static final String fileName="config.properties";
	static final String build_version="1.0";
	static final String rel_version="1.0";
	FileSystem fs;
	AlluxioURI path;
	

	AlluxioOPS()
	{
		fs = FileSystem.Factory.get();
	}
	
	private String getPermMask(String mode) 
	{
		String mask=String.valueOf(mode);
		
		mask=mask.replace("7", "rwx");
		mask=mask.replace("6", "rw-");
		mask=mask.replace("5", "r-x");
		mask=mask.replace("4", "r--");
		mask=mask.replace("3", "-wx");
		mask=mask.replace("2", "-w-");
		mask=mask.replace("1", "--x");
		mask=mask.replace("0", "---");
		return mask;
		
	}
    
	public void version(String args[])
	{
		
		System.out.println("Alluxio Wrapper Build version - " + build_version);
		System.out.println("Alluxio Wrapper Release version - " + rel_version);
		
	}
	
	//Copies a file from source (Alluxio) to target (Alluxio)
	//TODO: Need to update the functionality
	public void cp(String args[]) 
	{
		path = new AlluxioURI(args[1]);
		AlluxioURI destPath = new AlluxioURI(args[2]);
		try {
			
			//Files.copy(Paths.get("alluxio://"+"x01sadaapp34a.vsi.uat.dbs.com/tmp/Test.java"), Paths.get("alluxio://"+"x01sadaapp34a.vsi.uat.dbs.com/tmp/Test.java"));
			
			//FileUtils.copy(new File("alluxio://"+"x01sadaapp34a.vsi.uat.dbs.com/tmp/Test.java"),new File("alluxio://x01sadaapp34a.vsi.uat.dbs.com/tmp/Test-2018i"));
			//destPath=path;
			//CreateFileOptions.defaults().toOutStreamOptions().
			//fs2.createFile(args[1]);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	
	}

	public void copyToLocal(String args[]) 
	{
		path = new AlluxioURI(args[1]);
		String destPath = args[2];
		FileOutputStream osFile=null;
		byte [] data=new byte[Short.MAX_VALUE];
		int bytesRead=0;
	
		try {
			
			
			File fileInfo = new File(destPath);
			
			if (fileInfo.isDirectory() == true)
			{
				destPath=destPath.concat("/");
				destPath=destPath.concat(path.getName());			
			}
			
			osFile=new FileOutputStream(destPath);
			
			try (FileInStream is = fs.openFile(path)) {
				while ((bytesRead = is.read(data)) != -1) {
	                osFile.write(data);
	            }
			} catch ( IOException | AlluxioException e) {
				e.printStackTrace();
			} 
			osFile.close();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		finally {
			
		}
		
	}

	public void chmod(String args[]) 
	{
		path = new AlluxioURI(args[args.length - 1]);
		String recFlag="";
		String perm="";
		Mode m=Mode.defaults();
		SetAttributeOptions sa=SetAttributeOptions.defaults();
		if (args[1].compareTo("-R") == 0)
		{
			recFlag=args[1];
			perm=args[2];
			sa.setRecursive(true);
		}
		else
			perm = args[1];
		
		
		try {
			if (perm.charAt(0) == '7')
				m.setOwnerBits(Bits.ALL);
			else if (perm.charAt(0) == '6')
				m.setOwnerBits(Bits.READ_WRITE);			
			else if (perm.charAt(0) == '5')
				m.setOwnerBits(Bits.READ_EXECUTE);
			else if (perm.charAt(0) == '4')
				m.setOwnerBits(Bits.READ);
			else if (perm.charAt(0) == '3')
				m.setOwnerBits(Bits.WRITE_EXECUTE);
			else if (perm.charAt(0) == '2')
				m.setOwnerBits(Bits.WRITE);
			else if (perm.charAt(0) == '1')
				m.setOwnerBits(Bits.EXECUTE);
			else if (perm.charAt(0) == '0')
				m.setOwnerBits(Bits.NONE);

			if (perm.charAt(1) == '7')
				m.setGroupBits(Bits.ALL);
			else if (perm.charAt(1) == '6')
				m.setGroupBits(Bits.READ_WRITE);			
			else if (perm.charAt(1) == '5')
				m.setGroupBits(Bits.READ_EXECUTE);
			else if (perm.charAt(1) == '4')
				m.setGroupBits(Bits.READ);
			else if (perm.charAt(1) == '3')
				m.setGroupBits(Bits.WRITE_EXECUTE);
			else if (perm.charAt(1) == '2')
				m.setGroupBits(Bits.WRITE);
			else if (perm.charAt(1) == '1')
				m.setGroupBits(Bits.EXECUTE);
			else if (perm.charAt(1) == '0')
				m.setGroupBits(Bits.NONE);			

			if (perm.charAt(2) == '7')
				m.setOtherBits(Bits.ALL);
			else if (perm.charAt(2) == '6')
				m.setOtherBits(Bits.READ_WRITE);			
			else if (perm.charAt(2) == '5')
				m.setOtherBits(Bits.READ_EXECUTE);
			else if (perm.charAt(2) == '4')
				m.setOtherBits(Bits.READ);
			else if (perm.charAt(2) == '3')
				m.setOtherBits(Bits.WRITE_EXECUTE);
			else if (perm.charAt(2) == '2')
				m.setOtherBits(Bits.WRITE);
			else if (perm.charAt(2) == '1')
				m.setOtherBits(Bits.EXECUTE);
			else if (perm.charAt(2) == '0')
				m.setOtherBits(Bits.NONE);				
			
			sa.setMode(m);
			
			fs.setAttribute(path,sa);
		} catch (IOException | AlluxioException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	public void copyFromLocal(String args[]) 
	{
		path = new AlluxioURI(args[2]);
		String srcPath = args[1];
		File f=new File(srcPath);
		FileInputStream osFile=null;
		byte [] data=new byte[Short.MAX_VALUE];
		int bytesRead=0;
	
		try {
			osFile=new FileInputStream(srcPath);
			
			URIStatus fileInfo = fs.getStatus(path);

			if (fileInfo.isFolder() == true)
			{
				path=path.join("/");
				path=path.join(f.getName());
			}
			try (FileOutStream is = fs.createFile(path)) {
				
				while ((bytesRead = osFile.read(data)) != -1) {
	                is.write(data);
	            }
			} catch ( IOException | AlluxioException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			osFile.close();
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		finally {
			
		}
		
	}
	
	//Displays file listing
	public void ls(String args[]) throws IOException 
	{
		
		List<URIStatus> files;
	    try {
	    
	      files = fs.listStatus(new AlluxioURI(args[1]));
	    } catch (AlluxioException e) {
	      throw new IOException();
	    }
	    if (files == null) {
	      return;
	    }
	    ArrayList<String> ret = new ArrayList<String>(files.size());
	    
	    
	    for (URIStatus fileInfo : files) {
	    	
	      ret.add(
	    		  (fileInfo.isFolder() ? "d" : "-") +
	    		  getPermMask(Integer.toOctalString(fileInfo.toFileInfo().getMode())) + "\t" +
	    		  //fileInfo.getMode() + "\t\t" +
	    		  (fileInfo.toFileInfo().getOwner().length() == 0 ? "\t" :  fileInfo.toFileInfo().getOwner()) + "\t\t" +
	    		  (fileInfo.toFileInfo().getGroup().length() == 0 ? "\t" :  fileInfo.toFileInfo().getGroup()) + "\t\t" +
	    		  fileInfo.toFileInfo().getLength() + "\t\t" +
	    		  Instant.ofEpochMilli(fileInfo.toFileInfo().getLastModificationTimeMs()).
	    		  		atZone(ZoneId.systemDefault()).toLocalDateTime().toString().replace("T", " ") + "\t" +
	    		  fileInfo.toFileInfo().getPersistenceState() + "\t\t" +
	    		  fileInfo.toFileInfo().getInAlluxioPercentage() + "%\t\t" +
	    		  (fileInfo.toFileInfo().isPinned() ? "PINNED" : " ") + "\t" +
	    		  fileInfo.toFileInfo().getPath()
	    		  );
	      
	    }
	    
	    ret.forEach(System.out::println);
	    return;
	}
	
	//Creates directory
	public void mkdir(String args[])
	{
		path = new AlluxioURI(args[1]);
		try {
			fs.createDirectory(path);
		} catch (IOException | AlluxioException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void rm(String args[])
	{
		path = new AlluxioURI(args[1]);
		String recFlag="";
		
		if (args.length > 2)
			recFlag=args[2];
		
		try {
			fs.delete(path,(recFlag.compareTo("-R")==0 ? DeleteOptions.defaults().setRecursive(true) : DeleteOptions.defaults()));
		} catch (IOException | AlluxioException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void mv(String args[])
	{
		path = new AlluxioURI(args[1]);
		AlluxioURI destPath = new AlluxioURI(args[2]);
		try {
			fs.rename(path, destPath);
		} catch (IOException | AlluxioException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void touch(String args[])
	{
		
		path = new AlluxioURI(args[1]);
		System.out.println("Path is"+ path);
		// Create a file and get its output stream
		FileOutStream out;
		
		try{
			// Write data		
			out = fs.createFile(path);

			out.write("".getBytes());
			out.close();
		}
		catch (IOException e)
		{
				System.out.println("3.");		
		        e.printStackTrace();
		}
		catch (Exception e)
		{
				System.out.println("4.");		
		        e.printStackTrace();
		}


	}

	//Displays the contents of a file
	public void cat(String args[])
	{
		
		path = new AlluxioURI(args[1]);
		byte [] data=new byte[Short.MAX_VALUE];
		int bytesRead=0;
	
		
		try (FileInStream is = fs.openFile(path)) {
			while ((bytesRead = is.read(data)) != -1) {
                String msg = new String(data, 0, bytesRead);
                System.out.println(msg);
            }
		} catch ( IOException | AlluxioException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
	
	public void help()
	{
		System.out.println
				("Usage: AlluxioFS \n" +
				 "[cat <path>] \n" +
				 "[chmod [-R] <mode> <path>] \n" +						
				 "[copyFromLocal <src> <remoteDst>] \n" +						
				 "[copyToLocal <src> <localDst>] \n" +
				 "[help] \n" +				 
				 "[ls <path>] \n" +						
				 "[mkdir <path>] \n" +
				 "[mv <src> <dst>] \n" +
				 "[touch <path>] \n" +				 
				 "[rm <path> [-R]] \n" +				 
				 "[version] \n"				 
						);
	}
}

public class AlluxioFS {

	static final String fileName="config.properties";

	AlluxioURI path;
	
	static Properties adaProps = System.getProperties();
	
	static void setEnv() {
		

		try {
		//adaProps.load(new FileInputStream("config.properties"));		
		adaProps.load(AlluxioFS.class.getClassLoader().getResourceAsStream("config.properties"));
		System.setProperty("alluxio.zookeeper.enabled","true");
		System.setProperty("alluxio.zookeeper.address",adaProps.getProperty("zk_quorum"));
		System.setProperty("alluxio.security.authentication.type","KERBEROS");
		System.setProperty("alluxio.security.kerberos.service.name",adaProps.getProperty("krb_servicename"));
		System.setProperty("alluxio.security.kerberos.unified.instance.name",adaProps.getProperty("krb_instancename"));		
		System.setProperty("alluxio.user.file.readtype.default", adaProps.getProperty("readtype_default"));
		System.setProperty("alluxio.user.file.writetype.default", adaProps.getProperty("writetype_default"));
		
		} catch (IOException ae) {
			ae.printStackTrace();
		}
	}
	
	public static void main(String args[])
	{
		
		setEnv();
		
		AlluxioOPS fs1=new AlluxioOPS();
		
		if (args.length < 1)
			fs1.help();
		else if (args[0].compareTo("cat") == 0 && args.length >= 2) {
			fs1.cat(args);
		}
		else if (args[0].compareTo("chmod") == 0 && args.length >= 3) {
			fs1.chmod(args);
		}
		else if (args[0].compareTo("copyFromLocal") == 0 && args.length >= 3) {
			fs1.copyFromLocal(args);
		}
		else if (args[0].compareTo("copyToLocal") == 0 && args.length >= 3) {
			fs1.copyToLocal(args);
		}		
		else if (args[0].compareTo("help") == 0 && args.length >= 1) {
			fs1.help();
		}				
		else if (args[0].compareTo("ls") == 0 && args.length >= 2) {
			try {
				fs1.ls(args);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else if (args[0].compareTo("touch") == 0 && args.length >= 2) {
			fs1.touch(args);
		}

		else if (args[0].compareTo("mkdir") == 0 && args.length >= 2) {
			fs1.mkdir(args);
		}
		else if (args[0].compareTo("rm") == 0 && args.length >= 2) {
			fs1.rm(args);
		}
		else if (args[0].compareTo("mv") == 0 && args.length >= 2) {
			fs1.mv(args);
		}		
		else if (args[0].compareTo("cp") == 0 && args.length >= 2) {
			fs1.cp(args);
		}	
		else if (args[0].compareTo("version") == 0) {
			fs1.version(args);
		}
		else {
			fs1.help();
		}

	}
}
