zookeeper=`grep alluxio.zookeeper.address /opt/alluxio/conf/alluxio-site.properties | cut -d"=" -f2`
servicename=`grep alluxio.security.kerberos.service.name /opt/alluxio/conf/alluxio-site.properties | cut -d"=" -f2`
instancename=`grep alluxio.security.kerberos.unified.instance.name /opt/alluxio/conf/alluxio-site.properties | cut -d"=" -f2`

echo "Updating zookeeper address..."
sed -i "s/zookeeper/${zookeeper}/" $1
echo "Updating Service name..."
sed -i "s/srvcsname/${servicename}/" $1
echo "Updating Instance name..."
sed -i "s/instname/${instancename}/" $1