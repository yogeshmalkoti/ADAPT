#!/bin/bash

function set_osversion {
  export OSVERSION=$(uname -s)
}

function set_javahome {
  set_osversion
  case "${OSVERSION}" in
    Linux*)     $ADA_HOME/SPARK/lib/bigtop-utils/bigtop-detect-javahome;;
    Darwin*)    export JAVA_HOME=$(/usr/libexec/java_home);;
    CYGWIN*)    export JAVA_HOME=$JAVA_HOME;;
    MINGW*)     export JAVA_HOME=$JAVA_HOME;;
    *)          export JAVA_HOME="$JAVA_HOME"
  esac
}

function load_ada_config {
  if [ ! -z "$HOME" ] && [ -f "$HOME/.ada" ]; then
    source < $( grep = $HOME/.ada )
  fi
}

function detect_adahome {
  export SOURCE="${BASH_SOURCE[0]}"
  export BIN_DIR="$( dirname "$SOURCE" )"

  while [ -h "$SOURCE" ]
  do
    export SOURCE="$(readlink "$SOURCE")"
    [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
    export BIN_DIR="$( cd -P "$( dirname "$SOURCE"  )" && pwd )"
  done
  export BIN_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  export ADA_HOME="$( dirname ${BIN_DIR} )"
}

#ADA_HOME needs to be detected or configured in {HOME}/.ada
detect_adahome
load_ada_config
if [ -z "ADA_HOME" ]; then
  echo "ADA_HOME is not defined in $HOME/.ada. Please define your ADA_HOME in $HOME/.ada"
  exit -1
fi

#JAVA_HOME is compulsory for ADA toolkit
set_javahome
if [ -z "$JAVA_HOME" ]; then
  echo "ERROR: JAVA_HOME is not defined and cannot be detected (OS_VERSION: ${OSVERSION}). Please install JDK and define JAVA_HOME in your bash profile."
  exit -1
fi

#Clean
unset HADOOP_CONF_DIR

#Set HADOOP_HOME
export HADOOP_HOME=${ADA_HOME}/SPARK/lib/hadoop

echo "USER HOME: $HOME"
echo "ADA_HOME: $ADA_HOME"
echo "HADOOP_HOME: $HADOOP_HOME"
echo "JAVA_HOME: $JAVA_HOME"
$JAVA_HOME/bin/java -version
echo ""
