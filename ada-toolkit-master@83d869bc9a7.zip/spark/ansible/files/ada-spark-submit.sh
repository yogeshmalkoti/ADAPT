#!/bin/bash
SOURCE="${BASH_SOURCE[0]}"
BIN_DIR="$( dirname "$SOURCE" )"
while [ -h "$SOURCE" ]
do
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
  BIN_DIR="$( cd -P "$( dirname "$SOURCE"  )" && pwd )"
done
BIN_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

#Load ADA environment variables
if ! . $BIN_DIR/ada-env.sh ; then
  exit -1;
fi

#Create lineage directory
mkdir -p /tmp/log/spark/lineage
chmod -R 777 /tmp/log/spark/lineage

#Set SPARK environment variables
export SPARK_CONF_DIR=$ADA_HOME/SPARK/etc/spark/conf
#export ADA_SPARK_CONF="--conf spark.lineage.log.dir=/tmp/log/spark/lineage"

LIB_DIR=$ADA_HOME/SPARK/lib
exec $LIB_DIR/spark/bin/spark-submit "$@"
