#!/bin/bash

SOURCE="${BASH_SOURCE[0]}"
BIN_DIR="$( dirname "$SOURCE" )"
while [ -h "$SOURCE" ]
do
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
  BIN_DIR="$( cd -P "$( dirname "$SOURCE"  )" && pwd )"
done
BIN_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

#Load ADA environment variables
if ! . $BIN_DIR/ada-env.sh ; then
  exit -1;
fi

${ADA_HOME}/bin/ada-spark2-submit  --class org.apache.spark.examples.SparkPi --master yarn --deploy-mode cluster --conf spark.lineage.log.dir=/tmp/log/spark2/lineage ${ADA_HOME}/SPARK2/lib/spark2/examples/jars/spark-examples_2.11-2.2.0.cloudera2.jar 10
