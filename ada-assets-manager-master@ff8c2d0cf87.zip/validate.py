"""
python validate.py path/to/ada-assets

Validates the yml files against the json schema
Validates the unicity of the uids, gids, group and user names
Print the highest uid and gid
"""

from jsonschema import validate
import yaml
import io
import json
import os
import sys
import glob

schema = []
errors = []

uids = {}        # positive_integer -> file.yml:group:name
gids = {}        # positive_integer -> file.yml:group_name
group_names = {} # string           -> file.yml:application:
user_names  = {} # string           -> file.yml:application:group
users_groups = {} # string -> [ group_names ]

def _validate_unicity(app, file_path):
  """
  Validates the unicity of the uids, groups and users names
  """
  if 'groups' in app:
    for group in app['groups']:
      gid = group['gid']
      name = group['name']
      gid_v = f'{file_path}:{name}'
      gnid_v = f'{file_path}:{name}'
      if gid in gids:
        gid_v = f"{gids[gid]}, {gid_v}"
        errors.append(ValueError(f"Duplicate gid: {gid_v}"))
      if name in group_names:
        gnid_v = f"{group_names[name]}, {file_path}:{name}"
        errors.append(ValueError(f"Duplicate group name: {gnid_v}"))
      gids[gid] = gid_v
      group_names[name] = gnid_v
  if 'users' in app:
    for user in app['users']:
      uid = user['uid']
      name = user['name']
      uid_v = f'{file_path}:{name}'
      unid_v = f'{file_path}:{name}'
      if uid in uids:
        uid_v = f"{uids[uid]}, {uid_v}"
        errors.append(ValueError(f"Duplicate uid: {uid_v}"))
      if name in user_names:
        unid_v = f"{user_names[name]}, {file_path}:{name}"
        errors.append(ValueError(f"Duplicate user name: {unid_v}"))
      uids[uid] = uid_v
      user_names[name] = unid_v
      if not 'groups' in user or len(user['groups']) == 0:
        errors.append(ValueError(f"Missing groups attribute for user: {unid_v}"))
      users_groups[name] = user['groups']

def _validate(app_path):
  """
  Validates the asset file against the schema.
  """
  if not len(schema):
    # Find the schema in the current folder or its parent:
    schema_path = os.path.dirname(app_path) + os.sep + "assets-schema.json"
    if not os.path.exists(schema_path):
      schema_path2 = os.path.dirname(os.path.dirname(app_path)) + os.sep + "assets-schema.json"
      if not os.path.exists(schema_path2):
        raise ValueError(f"Could not find the assets-schema.json file: {schema_path} and {schema_path2} dont exist")
      else:
        schema_path = schema_path2
    # print('Using ' + schema_path)
    schema.append(json.load(io.open(schema_path, mode="r", encoding="utf-8")))

  f = io.open(app_path, mode="r", encoding="utf-8")
  app_yml = f.read()
  app = yaml.load(app_yml)
  schema_valid = True
  try:
    validate(app, schema[0])
  except Exception as err:
    schema_valid = False
    errors.append(app_path + " " + str(err.message) + " " + str(err.path))
    print(app_path + " " + str(err.message) + " " + str(err.path))
  if schema_valid:
    _validate_unicity(app, app_path)
  else:
    sys.exit()

if len(sys.argv) >= 2:
  folder = sys.argv[1]
else:
  folder = "../ada-assets"

if folder.startswith("-h"):
  print("""python validate.py path/to/applications/folder""")
  sys.exit()


if os.path.isdir(folder):
    folder = folder + os.sep + "**" + os.sep + "*.yaml"

for file in glob.glob(folder):
    if file.endswith('.yaml') or file.endswith('.yml'):
        print(f"Validating {file}")
        _validate(file)

max_uid = max(uids.keys())
max_gid = max(gids.keys())
print(f"Max uid: {max_uid} - {uids[max_uid]}")
print(f"Max gid: {max_gid} - {gids[max_gid]}")

for user in users_groups:
  groups = users_groups[user]
  for group in groups:
    if not group in group_names:
      errors.append(ValueError(f"Unknown group \"{group}\" for user: {user} - {user_names[user]}"))

for err in errors:
  print(err)

if len(errors):
  sys.exit(1)
