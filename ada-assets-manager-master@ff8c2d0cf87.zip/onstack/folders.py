#!/bin/python
import argparse
import yaml
import os
import shutil
import sys
import glob

hive_roles = {}

def setup_alluxio_folder(path_name, owner_name, group_name, mode_name):
    alluxio_path = path_name.split(':')[1]
    return """
alluxio fs mkdir {alluxio_path}
alluxio fs chown {owner_name} {alluxio_path}
alluxio fs chgrp {group_name} {alluxio_path}
alluxio fs chmod {mode_name} {alluxio_path}
""".format(alluxio_path=alluxio_path, owner_name=owner_name, group_name=group_name, mode_name=str(mode_name))

def setup_hdfs_folder(path_name, owner_name, group_name, mode_name):
    hdfs_path = path_name.split(':')[1]
    return """
hadoop fs -mkdir {hdfs_path} 
hadoop fs -chown {owner_name} {hdfs_path}
hadoop fs -chgrp {group_name} {hdfs_path}
hadoop fs -chmod {mode_name} {hdfs_path}
""".format(hdfs_path=hdfs_path, owner_name=owner_name, group_name=group_name, mode_name=str(mode_name))

def setup_folder(script_alluxio, script_hdfs, folder):
    """
    Scripts to create the alluxio and hdfs assets
    """
    path_name = folder['path']
    if  path_name.startswith('alluxio'):
        script_alluxio.append(setup_alluxio_folder(path_name, folder['owner'], folder['group'], folder['mode']))

    elif path_name.startswith('hdfs'):
        script_hdfs.append(setup_hdfs_folder(path_name, folder['owner'], folder['group'], folder['mode']))

def setup_mount(script_alluxio, mount, account, adastack):

    if account != mount['account'] or adastack != mount['stack']:
        # skip: this is for a different stack
        # print("Skipping %s" % mount)
        return

    # Remove the "alluxio:" protocol:
    target = mount['target'].split(':')[1]

    script_alluxio.append("""
#todo: make this idempotent and error proof
#alluxio fs mv {target} {target}.bkp'
alluxio fs mount {source} {target}
alluxio fs chown {owner} {target}
alluxio fs chgrp {group} {target}
alluxio fs chmod {mode} {target}
""".format(target=target, source=mount['source'], owner=mount['owner'], group=mount['group'], mode=str(mount['mode'])))

def setup_hive(script_hive, hive, app_name):

    text = []

    grant_name = ''
    if 'grant' in hive:
        grant_name = hive['grant']
    group_name = ''
    if 'group' in hive:
        group_name = hive['group']
    database_name = ''
    if 'database' in hive:
        database_name = hive['database']
    uri_loc = ''
    if 'uri' in hive:
        uri_loc = hive['uri']

    role = ''
    if grant_name and app_name and group_name:
        role = "{app_name}_{group_name}_{grant_name}".format(
            app_name=app_name, group_name=group_name, grant_name=grant_name).replace(',', '_')
        
    if role and not role in hive_roles:
        text.append("create role {role};".format(role=role))

    if database_name:
        text.append("create database {database_name};".format(database_name=database_name))

    if role and grant_name and database_name and group_name:
        text.append("grant {grant_name} on database {database_name} to role {role};".format(grant_name=grant_name, database_name=database_name, role=role))

    if uri_loc and grant_name and role and group_name:
        text.append("grant {grant_name} on URI '{uri_loc}' to role {role};".format(grant_name=grant_name, uri_loc=uri_loc, role=role))

    if role and not role in hive_roles:
        if (uri_loc and grant_name and role and group_name) or (role and grant_name and database_name and group_name):
            text.append("grant role {role} to group {group_name};".format(role=role, group_name=group_name))
            hive_roles[role] = True
    text.append('')
    script_hive.append("\n".join(text))

def setup_folders(script_path, assets_globs, account, stack, environment):

    if not assets_globs:
        assets_glob = "../ada-assets"
    if not script_path:
        script_path = "/tmp/onstack_dirs"
    if os.path.isdir(script_path):
        shutil.rmtree(script_path)
    os.mkdir(script_path)

    env_code = {
        'dev': 'b',
        'sit': 'b',
        'uat': 's',
        'prod': 'g'
    }[environment]

    if not isinstance(assets_globs, list):
        # if not an array, assume it is a string and make it into an array
        # (dont want to test for string as it is different in python2 and python3)
        assets_globs = assets_globs.split(',')

    scripts = {
        'alluxio': [],
        'hive': [],
        'hdfs': []
    }

    for assets_glob in assets_globs:
        if os.path.isdir(assets_glob):
            assets_glob = assets_glob + os.sep + "**" + os.sep + "*.yaml"

        for file in glob.glob(assets_glob):
            app_yaml = yaml.load(open(file))
            if not 'name' in app_yaml:
                raise ValueError("Missing attribute name in the application descriptor of {file}".format(file=file))
            app_name = app_yaml['name']
            if 'folders' in app_yaml:
                print("Processing the folders of " + app_yaml['name'] + "\n")
                for folder in app_yaml['folders']:
                    setup_folder(scripts['alluxio'], scripts['hdfs'], folder)
            if 'hive' in app_yaml:
                print("Processing the hive declarations of " + app_yaml['name'] + "\n")
                for hive in app_yaml['hive']:
                    setup_hive(scripts['hive'], hive, app_name)
            if 'mounts' in app_yaml:
                print("Processing the mounts of " + app_yaml['name'] + "\n")
                for mount in app_yaml['mounts']:
                    setup_mount(scripts['alluxio'], mount, account, stack)

    # serialize the scripts in files.
    for key in scripts:
        lines = scripts[key]
        if lines:
            # if key == 'hive':
            #     if environment == 'prod':
            #         addomain = 'SVCS.DBS.COM'
            #     else:
            #         addomain = 'SVCSUAT.DBS.COM'
            #     beeline =    
            #         "cacerts_path=/etc/pki/ca-trust/extracted/java/cacerts; " +
            #         "current_host=ada-dev-master-0.dev6.nonprod.c0.dbs.com; " +
            #         "beeline -u \"jdbc:hive2://$current_host:10000/app_frdv;ssl=false;sslTrustStore=$cacerts_path;trustStorePassword=changeit;principal=hive/_HOST@SVCSUAT.DBS.COM\""
            #     lines.insert(0, beeline)

            with open(script_path + os.sep + "folders_{key}.sh".format(key=key), "w") as text_file:
                text_file.write("\n".join(lines).format(env_code=env_code))


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="Generate bash scripts to setup hive alluxio hdfs on an ada cluster")

    parser.add_argument("-d", "--directory", dest="directory", required=True, help="yml directory or list of globs to select the asset descriptors")
    parser.add_argument("-t", "--tmpdir", dest="tmpdir", required=False, help="path to the directory where the bash scripts are generated. default /tmp/onstack_dirs")
    parser.add_argument("-a", "--account", dest="account", required=False, help='account: dev6, uatdatascience, uat or prod')
    parser.add_argument("-s", "--adastack", dest="adastack", required=False, help='adastack: name of the stack targeted')
    parser.add_argument("-e", "--env", dest="environment", required=True, help='environment: dev, uat or prod')

    args = parser.parse_args()

    setup_folders(args.tmpdir, args.directory, args.account, args.adastack, args.environment)
