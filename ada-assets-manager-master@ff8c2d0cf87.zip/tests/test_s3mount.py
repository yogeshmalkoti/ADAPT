import s3mount

_username = 'adauser1'
_password = ''
_key_filename = "id_rsa_2048_a_adauser1_x01sadaapp1a_shared.pem"
#_alluxioserver = "x01sadaapp36a.vsi.uat.dbs.com x01sadaapp35a.vsi.uat.dbs.com"
_alluxioserver = "x01sadaapp32a.vsi.uat.dbs.com"
_data_file = "mount_test.yaml"
_alluxio_keytab = "/opt/alluxio/conf/alluxiocliuat.keytab"
_hdfs_keytab = "/home/adauser1/keys/hdfs.keytab"
_jen_stack = "ada-dev"
_jen_account = "dev6"
#alluxio..usage() ## Print usage ###


s3mount.py_mount(_username, _key_filename, _alluxioserver, _data_file, _alluxio_keytab, _jen_account, _jen_stack, _password='', _sudo_cmd='')

#asset file used for testing is  frdvapp.yml from ada-assest
