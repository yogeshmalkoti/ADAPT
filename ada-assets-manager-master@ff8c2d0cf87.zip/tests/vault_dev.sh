#!/bin/bash
# chdir to the assetmanager/vault folder
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" && cd ..

[ -d tmp ] && rm -rf tmp
mkdir -p tmp
vault audit enable file file_path="$(pwd)/tmp/audit_log"

vault policy write admin policies/audit.hcl
vault policy write apps policies/APPS.hcl
vault policy write provision policies/provision.hcl

vault auth enable ldap
vault auth enable userpass

# test users
VAULT_TOKEN=root vault write "auth/userpass/users/auditor" policies="audit" password="auditor"
