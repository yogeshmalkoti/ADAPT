import hive

_username = 'adauser1'
_password = ''
_key_filename = "id_rsa_2048_a_adauser1_x01sadaapp1a_shared.pem"
_hiveserver = "x01sadaapp36a.vsi.uat.dbs.com x01sadaapp35a.vsi.uat.dbs.com"
_data_file = "hive_test.yaml"
_keytab = "/home/adauser1/keys/hue.keytab"

#hive.usage() ## Print usage ###

hive.py_hive(_username, _key_filename, _hiveserver, _data_file, _keytab, _password='', _truststore='/tmp/cacerts',_truststorepass='changeit', _sudo_cmd='')




