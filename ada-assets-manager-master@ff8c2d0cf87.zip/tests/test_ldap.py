#!/bin/python

import createuser

_ldapserver='ldaps://w01s1svcsdcs1a.SVCSUAT.DBS.COM:636'
_binddn='clderaadm1@SVCSUAT.DBS.COM'
_bindpass='XXXXXXX'
_data_file='ldap_test.yaml'
_base_dn='ou=ADA,ou=APPS,dc=SVCSUAT,dc=DBS,dc=COM'

createuser.py_ldap(_ldapserver, _binddn, _bindpass, _data_file, _base_dn)
