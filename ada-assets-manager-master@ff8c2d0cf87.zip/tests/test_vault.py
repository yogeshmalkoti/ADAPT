import pytest

import hvac

import os
import subprocess

from vault import upsert
from vault.reader import *

# Environment variables to point at the in-memory vault
VAULT_DEV_LISTEN_ADDRESS = "127.0.0.1:7200"
VAULT_ADDR = "http://" + VAULT_DEV_LISTEN_ADDRESS
VAULT_DEV_ROOT_TOKEN_ID = "root"
os.environ["VAULT_DEV_ROOT_TOKEN_ID"] = VAULT_DEV_ROOT_TOKEN_ID
os.environ["VAULT_ADDR"] = VAULT_ADDR

@pytest.fixture(scope="session", autouse=True)
def setup_module():
  vault_proc = _start_vault_dev()
  print(vault_proc)
  yield
  _stop_vault_dev(vault_proc)

def _start_vault_dev():
  """ Start an in-memory vault for testing """
  cmd = "vault server -dev -dev-listen-address=" + VAULT_DEV_LISTEN_ADDRESS
  vault_proc = subprocess.Popen(cmd, shell=True)
  subprocess.run("env | grep VAULT; bash tests/vault_dev.sh", shell=True)
  return vault_proc

def _stop_vault_dev(vault_proc):
  """ Stop the in-mem vault """
  vault_proc.terminate()
  vault_proc.wait()

def test_vault_sane():
  client = hvac.Client(url=VAULT_ADDR, token=VAULT_DEV_ROOT_TOKEN_ID)
  assert client.is_authenticated()

def test_create_user_policy():
  """Test creating a single user policy"""
  result = upsert.create_user_policy('hugues', allFctId=['fct1'], admin=True)
  expected_result = """
path "secret/1bankid/hugues" {
  capabilities = ["read", "list"]
}
path "secret/1bankid/hugues/*" {
  capabilities = ["read", "list"]
}

path "secret/keytab/fct1" {
  capabilities = ["read", "list"]
}
# read write zone shared by fctid
path "secret/rw/fct1" {
  capabilities = ["create", "update", "delete", "read", "list"]
}
path "secret/rw/fct1/*" {
  capabilities = ["create", "update", "delete", "read", "list"]
}
"""
  assert result == expected_result


def test_all_users_policies():
  """Test creating user policies from yaml file"""
  testBankIds = ["test1bankid1", "test1bankid2", "test1bankid3"]
  yamlFile = YamlReader("./tests/assets/testapp1.yml")

  for bankId in testBankIds:
      fctId = yamlFile.get_fctId_for_bankId("testapp1", bankId)
      result = upsert.create_user_policy(bankId, allFctId=fctId, admin=True)
      expected_result = open(f'''./tests/assets/expected_result_{bankId}.txt''' , 'r').read()
      assert result == expected_result


def test_create_user():
  """
  Test creating user, including the uploading of policies and read/write compliance test btn users.
  """
  testBankIds = ["test1bankid1", "test1bankid2", "test1bankid3"]
  yamlFile = YamlReader("./tests/assets/testapp1.yml")
  client = hvac.Client(url=VAULT_ADDR, token=VAULT_DEV_ROOT_TOKEN_ID)

  for bankId in testBankIds:
      client.token = VAULT_DEV_ROOT_TOKEN_ID
      fctId = yamlFile.get_fctId_for_bankId("testapp1", bankId)
      userPolicyDetails = upsert.create_user_policy(bankId, allFctId=fctId, admin=True)
      userPolicyName = f"""UserPolicy_{bankId}"""
      upsert.upload_policy(client = client, policyName = userPolicyName, policyDetails = userPolicyDetails)
      createUser = upsert.create_user(client = client, loginType = "userpass", bankId = bankId, pwd = "foo", userPolicy=userPolicyName)
      authResult = client.auth_userpass(bankId, 'foo')
      user = authResult["auth"]["metadata"]["username"]
      assert bankId == user

  #Compliance test: To check security of reading/writing another users path
  #As testbankid1, it can:
  #read its own secret/1bankid only
  #reads its own testfctid1
  client.token = VAULT_DEV_ROOT_TOKEN_ID
  authResult = client.auth_userpass("test1bankid1", 'foo')
  client.read("secret/1bankid/test1bankid1")
  client.read("secret/keytab/testfctid1")
  client.read("secret/rw/testfctid1")
  client.write("secret/rw/testfctid1", value = 123)
  with pytest.raises(hvac.exceptions.Forbidden):
    client.read("secret/1bankid/test1bankid2")
    client.read("secret/keytab/testfctid2")
    client.write("secret/rw/testfctid2", value = 123)
    client.write("secret/rw/testfctid3", value = 123)
    client.write("secret/keytab/test1bankid2", value = 123)
    client.write("secret/keytab/test1bankid3", value = 123)

  #As testbankid2, it can:
  #read its own secret/1bankid
  #read/write to testfctid2 and testfctid3
  client.token = VAULT_DEV_ROOT_TOKEN_ID
  authResult = client.auth_userpass("test1bankid2", 'foo')
  client.read("secret/1bankid/test1bankid2")
  client.read("secret/keytab/testfctid2")
  client.read("secret/rw/testfctid2")
  client.read("secret/rw/testfctid3")
  client.write("secret/rw/testfctid2", value = 123)
  client.write("secret/rw/testfctid3", value = 123)
  with pytest.raises(hvac.exceptions.Forbidden):
    client.read("secret/1bankid/test1bankid1")
    client.read("secret/1bankid/test1bankid3")
    client.read("secret/keytab/testfctid1")
    client.read("secret/rw/testfctid1")
    client.write("secret/1bankid/test1bankid1", value = 123)
    client.write("secret/keytab/test1bankid1", value = 123)

  #As testbankid3, it can:
  #read its own secret/1bankid
  #read/write to testfctid2 only
  client.token = VAULT_DEV_ROOT_TOKEN_ID
  authResult = client.auth_userpass("test1bankid3", 'foo')
  client.read("secret/1bankid/test1bankid3")
  client.read("secret/rw/testfctid2")
  client.write("secret/rw/testfctid2", value = 123)
  with pytest.raises(hvac.exceptions.Forbidden):
    client.read("secret/1bankid/test1bankid1")
    client.read("secret/1bankid/test1bankid3")
    client.read("secret/keytab/testfctid1")
    client.read("secret/keytab/testfctid3")
    client.read("secret/rw/testfctid1")
    client.read("secret/rw/testfctid3")
    client.write("secret/1bankid/test1bankid1", value = 123)
    client.write("secret/keytab/test1bankid1", value = 123)
    client.write("secret/rw/testfctid3", value = 123)
