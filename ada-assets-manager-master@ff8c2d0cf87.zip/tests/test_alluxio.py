import alluxio 

_username = 'adauser1'
_password = ''
_key_filename = "id_rsa_2048_a_adauser1_x01sadaapp1a_shared.pem"
#_alluxioserver = "x01sadaapp36a.vsi.uat.dbs.com x01sadaapp35a.vsi.uat.dbs.com"
_alluxioserver = "x01sadaapp32a.vsi.uat.dbs.com"
_data_file = "alluxio_test.yaml"
_alluxio_keytab = "/opt/alluxio/conf/alluxiocliuat.keytab"
_hdfs_keytab = "/home/adauser1/keys/hdfs.keytab"

#alluxio..usage() ## Print usage ###

alluxio.py_alluxio(_username, _key_filename, _alluxioserver, _data_file, _alluxio_keytab, _hdfs_keytab, _password='', _sudo_cmd=''):



