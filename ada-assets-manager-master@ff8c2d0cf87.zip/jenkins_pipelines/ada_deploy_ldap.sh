#!/bin/bash

#clean up the previous run
rm -f ada_asset_ldap.py

if [ "$do_ldap" != true ]; then
    # Nothing to do.
    exit 0
fi

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [[ "$NODE_LABELS" = *AWS* ]]; then
    if [[ "$NODE_LABELS" = *DEV* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/dev6.bash"
    elif [[ "$NODE_LABELS" = *UAT* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/uatdatascience.bash"
    elif [[ "$NODE_LABELS" = *PROD* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/proddatascience.bash"
    fi
else
    export ADA_USER=${ADA_USER:-adauser1}
    echo "WARN: please setup extra env variable for on-premise"
    exit 1
fi


#generate the python script
#== ada_ldap.py
cat <<EOF >> ada_asset_ldap.py

import sys
sys.path.append('./ldap')
import createuser

_ldapserver="${AD_LDAP_SERVER}"
_binddn="clderaadm1@${AD_DOMAIN}"
_bindpass="${AD_BIND_PASS}"
file_glob="${ASSETS_GLOB}".split(",")
_base_dn="${AD_BASE_DN}"
users_to_select_globs="${users_to_select_globs:-*}".split(",")
users_to_just_reset_password_globs="${users_to_just_reset_password_globs}".split(",")
users_to_delete_globs="${users_to_delete_globs}".split(",")
environment="${ENV_LVL}"

createuser.py_ldap(_ldapserver, _binddn, _bindpass, file_glob, _base_dn,
    users_to_select_globs, users_to_just_reset_password_globs, users_to_delete_globs, environment)

EOF
#-----------------
python ada_asset_ldap.py
