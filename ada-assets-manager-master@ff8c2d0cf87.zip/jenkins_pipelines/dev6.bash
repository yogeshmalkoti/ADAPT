#!/bin/bash
export aws_accnt=dev6
export ADA_DOMAIN=${aws_accnt}.nonprod.c0.dbs.com
export ADA_USER=ec2-user
export AD_DOMAIN=SVCSUAT.DBS.COM
export AD_LDAP_SERVER=ldaps://w01s1svcsdcs1a.SVCSUAT.DBS.COM:636
[ -z "$AD_BASE_DN" ] && export AD_BASE_DN="ou=ADA,ou=APPS,dc=SVCSUAT,dc=DBS,dc=COM"
export ENV_LVL=dev