#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR/.." || exit 1
if [[ "$NODE_LABELS" = *AWS* ]]; then
    if [[ "$NODE_LABELS" = *DEV* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/dev6.bash"
    elif [[ "$NODE_LABELS" = *UAT* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/uatdatascience.bash"
    elif [[ "$NODE_LABELS" = *PROD* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/proddatascience.bash"
    fi
else
    export ADA_USER=${ADA_USER:-adauser1}
    echo "WARN: please setup extra env variable for on-premise"
    exit 1
fi

python3 vault/uploadkeytabs.py --directory $WORKSPACE/ada-assets-manager/KEYTABS/ --token "$VAULT_DEV6_PROVISION" --url "$VAULT_ADDR"
python3 vault/createvaultusers.py --directory $WORKSPACE/ada-assets \
    --fixed "vault/policies/*.hcl" --token "$VAULT_DEV6_PROVISION" --url "$VAULT_ADDR" --env "$ENV_LVL"

