#!/bin/bash

############################################################################
#   Program name: ADA.sh
#   Program type: Linux Shell script
#   Date        :
#   Log File    : talend_db.log
#   Description : This Shell script will Hive DB for DI Team.

############################################################################
#hive_master="ada-dev-master-0.dev6.nonprod.c0.dbs.com"
storepath="/usr/java/latest/jre/lib/security/cacerts"
storepass="changeit"
hive_keytab="/run/cloudera-scm-agent/process/424-hive-HIVESERVER2/hive.keytab"
hive_princ=$(klist -k $hive_keytab | grep dbs | grep hive | head -n1 | awk '{print$2}')

kinit -kt $hive_keytab $hive_princ

beelineuri="beeline -u \"jdbc:hive2://$hive_master:10000/default;ssl=true;sslTrustStore=$storepath;trustStorePassword=$storepass;principal=hive/_HOST@SVCSUAT.DBS.COM\""

arr=$*
echo '***********************************************************' | tee -a talend_db.log
echo "Got paylod at `date` for below database requests:" | tee -a talend_db.log
echo "$arr" | tee -a talend_db.log
echo | tee -a talend_db.log

IFS=' ' read -a arr1 <<< "$arr"
{
for DATABASE_NAME in "${arr1[@]}"
do
CURRENT_DATE=$(date +%d_%b_%Y_%H:%M:%S)
sed -e "s/DATABASE_NAME/$DATABASE_NAME/g" -e "s/CURRENT_DATE/$CURRENT_DATE/g" `pwd`/talend.hql.raw1 >`pwd`/talend.hql1
$beelineuri -f `pwd`/talend.hql1 > hql1.out 2>&1

grep  "Error:" hql1.out | grep -v "Database $DATABASE_NAME already exists">/dev/null 2>&1
rc1=$?

grep  "Error:" hql1.out | grep "Database $DATABASE_NAME already exists"  >/dev/null 2>&1
rc2=$?

if [ $rc1 -eq 0 ]
then
grep -i "Error" hql1.out | tee -a talend_db.log
echo -e "\nERROR Encountered. Exiting ...\n" | tee -a talend_db.log
exit
fi

if [ $rc2 -eq 0 ]
then
echo "Database $DATABASE_NAME already exists " | tee -a talend_db.log
else
sed -e "s/DATABASE_NAME/$DATABASE_NAME/g" -e "s/CURRENT_DATE/$CURRENT_DATE/g" `pwd`/talend.hql.raw2 >`pwd`/talend.hql2
$beelineuri -f `pwd`/talend.hql2 > hql2.out 2>&1
echo "Database $DATABASE_NAME created successfully at $CURRENT_DATE " | tee -a talend_db.log
fi
done
}

kdestroy
echo | tee -a talend_db.log
echo "Execution Finished  at `date` " | tee -a talend_db.log
echo | tee -a talend_db.log
