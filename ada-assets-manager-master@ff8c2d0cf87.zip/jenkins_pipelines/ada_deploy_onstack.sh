#!/bin/bash

if [ -z "$adastack" ]; then
    # Nothing to do
    exit 0
fi

WORKSPACE=${WORKSPACE:-$PWD}

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [[ "$NODE_LABELS" = *AWS* ]]; then
    if [[ "$NODE_LABELS" = *DEV* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/dev6.bash"
    elif [[ "$NODE_LABELS" = *UAT* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/uatdatascience.bash"
    elif [[ "$NODE_LABELS" = *PROD* ]]; then
        #shellcheck disable=SC1090
        source "$DIR/proddatascience.bash"
    fi
else
    export ADA_USER=${ADA_USER:-adauser1}
    echo "WARN: please setup extra env variable for on-premise"
    exit 1
fi

if [ -z "$vault_keytabs_download" ]; then
  if [ "$aws_accnt" = "dev6" ]; then
    vault_keytabs_download=${vault_dev6_keytabs_download}
  elif [ "$aws_accnt" = "uatdatascience" ]; then
    vault_keytabs_download=${vault_uatdatascience_keytabs_download}
  elif [ "$aws_accnt" = "proddatascience" ]; then
    vault_keytabs_download=${vault_proddatascience_keytabs_download}
  fi
fi

# prepare the bash scripts
python3 onstack/folders.py -d "$WORKSPACE/ada-assets" --account="$aws_accnt" --adastack="$adastack" --env="$ENV_LVL"

if [ ! -f "$HOME/.ansible.cfg" ]; then
   echo "[defaults]
host_key_checking = False
[ssh_connection]
scp_if_ssh = True
" > "$HOME/.ansible.cfg"
fi

envsubst < "$WORKSPACE/ada-inventories/ADA-$adastack/extras.json" > "$WORKSPACE/.extras-$adastack.json"

inventory_file=$WORKSPACE/ada-inventories/ADA-$adastack/ADA-$adastack.inventory
roles="hdfs hive alluxio keytabs"
for role in $roles; do
    ansible-playbook $ansible_verbosity -i "$inventory_file" -e "$WORKSPACE/@.extras-${adastack}.json" \
    -e "vault_token=$VAULT_DEV6_KEYTABS_DOWNLOAD" \
    -e "vault_keytabs_download=$vault_keytabs_download" \
    -e "alluxio_security_kerberos_unified_instance_name=$alluxio_security_kerberos_unified_instance_name" \
    -e "scripts_source_dir=$WORKSPACE/ada-assets" \
    --key-file "$HOME/.ssh/ada-node-$aws_accnt.pem" \
    "site-deploy-$role.yml"
done