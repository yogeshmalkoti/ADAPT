import argparse, base64, hvac
import os
import glob

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="keytab download tool")
    parser.add_argument("-d", "--directory", dest="directory", required=True, help='keytab directory')
    parser.add_argument("-t", "--token", dest="token", required=True, help='vault token')
    parser.add_argument("-u", "--url", dest="url", required=True, help='vault_url')
    parser.add_argument("-v", "--verbose", dest="verbose", required=False, help="verbose output if set to True")

    args = parser.parse_args()
    vault_token, vault_url = args.token, args.url

    client = hvac.Client(url=vault_url, token=vault_token, verify=False)
    keytablist = client.list(f"""/secret/fctid""")['data']['keys']
    for keytab in keytablist:
        keytab_bin = (base64.b64decode(client.read(f"""/secret/fctid/{keytab}/keytab""")['data']['keytab']))
        outputfile = open(f"""{args.directory}/{keytab[:-1]}.keytab""", "wb")
        outputfile.write(keytab_bin)
        outputfile.close()
