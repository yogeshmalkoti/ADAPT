import reader, os, upsert, hvac, random, uuid
import argparse
import glob

def getidentities(filelist):
    ids = []
    for file in filelist:
        print("Processing " + file)
        ymldata = reader.YamlReader(file).data
        ids.append([{ 'app_name': ymldata['name'], 'userdata' : ymldata['users'] }])
    return ids

def createusers(envs, client):
    for bankId in envs.keys():
        print(f"""1bankId: {bankId}, functional ids {envs[bankId]}""")
        userpolicy = upsert.create_user_policy(bankId, allFctId=envs[bankId])
        userPolicyName = f"""1bankid_{bankId}"""
        upsert.upload_policy(client = client, policyName = userPolicyName, policyDetails = userpolicy)
        upsert.create_user(client = client, loginType = "ldap", bankId = bankId, pwd = "", userPolicy=userPolicyName, fctids = envs[bankId])
        # print(userpolicy)
        print(userPolicyName)
        print('=========')

def upload_fixed_policies(client, fixed_policies_glob):
    if os.path.isdir(fixed_policies_glob):
        fixed_policies_glob = fixed_policies_glob + os.sep + "*.hcl"
    for hclfile in glob.glob(fixed_policies_glob):
        name = os.path.splitext(os.path.basename(hclfile))[0]
        data = open(hclfile, encoding='utf8').read()
        print(f"Uploading fixed policy: {name}")
        client.set_policy(name, data)

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="keytab upload tool")

    parser.add_argument("-d", "--directory", dest="directory", required=True, help='yml directory')
    parser.add_argument("-t", "--token", dest="token", required=True, help='vault token for provisioner')
    parser.add_argument("-u", "--url", dest="url", required=True, help='vault_url')
    parser.add_argument("-v", "--verbose", dest="verbose", required=False, help="verbose output if set to True")
    parser.add_argument("-e", "--env", dest="environment", required=True, help='environment: dev, uat or prod')
    parser.add_argument("-f", "--fixed", dest="fixed_policies_glob", required=False, help='Fixed policies files glob')

    args = parser.parse_args()
    client = hvac.Client(url=args.url, token=args.token, verify=False)

    if 'fixed_policies_glob' in args and args.fixed_policies_glob:
        upload_fixed_policies(client, args.fixed_policies_glob)

    ymlfilelist = glob.glob(args.directory + os.sep + "**" + os.sep + "*.yaml")

    ids = {}

    env_code = {
        'dev': 'b',
        'sit': 'b',
        'uat': 's',
        'prod': 'g'
    }[args.environment]

    identities = getidentities(ymlfilelist)

    for eachidlist in identities:
        for userdatalist in eachidlist:
            for each in userdatalist['userdata']:
                bankids_lvl = f"""1bankids_{args.environment}"""
                if bankids_lvl in each:
                    for eachid in each[bankids_lvl]:
                        # Replace the env_code
                        fctid = each['name'].format(env_code=env_code)
                        if eachid in ids.keys():
                            ids[eachid].append(fctid)
                        else:
                            ids.update({eachid: [fctid]})

    print(f"===={ids}====")
    createusers(ids, client)
