import argparse, base64, hvac
import os
import platform
import glob
from subprocess import Popen, PIPE, STDOUT

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def encode_keytab(keytab):
    indata = open(keytab, 'rb').read()
    return str(base64.b64encode(indata))[2:-1] # striping off extra characters

def get_principal(keytab_path):
    if platform.system() == 'Darwin':
        get_princ_cmd = f"ktutil -k {keytab_path} list | tail -1 | awk '{{print $3}}'"
    else:
        get_princ_cmd = f"klist -k {keytab_path} | tail -1 | awk '{{print $2}}'"
    proc = Popen(get_princ_cmd, stdout=PIPE, stderr=STDOUT, shell=True)
    out, _ = proc.communicate()
    assert proc.returncode == 0, "failed to read keytab " + keytab_path
    return out.decode("utf-8").strip()

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="keytab upload tool")
    parser.add_argument("-d", "--directory", dest="directory", required=True, help='keytab directory')
    parser.add_argument("-t", "--token", dest="token", required=True, help='vault token')
    parser.add_argument("-u", "--url", dest="url", required=True, help='vault_url')

    args = parser.parse_args()
    vault_token, vault_url = args.token, args.url

    client = hvac.Client(url=vault_url, token=vault_token, verify=False)
    filelist = glob.glob(args.directory + os.sep + "*.keytab")
    for keytab in filelist:
        fctid = os.path.splitext(os.path.basename(keytab))[0].split('-')[0]
        key = f"""secret/fctid/{fctid}/keytab"""
        principal = get_principal(keytab)
        print(keytab + ": " + key + " " + principal + " " + args.token)            
        client.write(key, keytab=encode_keytab(keytab), principal=principal)
