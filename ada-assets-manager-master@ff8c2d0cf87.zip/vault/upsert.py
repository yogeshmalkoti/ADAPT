"""
Methods to upsert a user in vault
"""

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import hvac
import os
from reader import *


def get_client():
  client = hvac.Client(os.environ['VAULT_ADDR'], os.environ['VAULT_TOKEN'])
  assert client.is_authenticated()
  return client


def create_user_policy(*args, **kwargs):
  """
  bankid, allFctId = [], admin=True, provision=True, audit=True 
  """
  bankid = args[0]

  user_policy = f'''
path "secret/1bankid/{bankid}" {{
  capabilities = ["read", "list"]
}}
path "secret/1bankid/{bankid}/*" {{
  capabilities = ["read", "list"]
}}
path "sys/policy/1bankid_{bankid}" {{
  capabilities = ["read"]
}}
'''
  
  for fctid in kwargs["allFctId"]:
    user_policy += f'''
path "secret/fctid/{fctid}/*" {{
  capabilities = ["read", "list"]
}}
path "secret/rw/{fctid}" {{
  capabilities = ["create", "update", "delete", "read", "list"]
}}
path "secret/rw/{fctid}/*" {{
  capabilities = ["create", "update", "delete", "read", "list"]
}}
'''

  return user_policy


def upload_policy(**kwargs):
  """
  Create the policy, input should be client= , policyName= , policyDetails=,
  """
  client = kwargs["client"]
  client.set_policy( kwargs["policyName"], kwargs["policyDetails"])


def create_user(**kwargs):
  """
  Create the user, input should by client= ,loginType = , bankId = , pwd = , userPolicy = , fctId =, admin=True, provision=True, audit=True
  """
  client = kwargs["client"]
  bankId = kwargs["bankId"]
  pwd = kwargs["pwd"]
  userPolicy = kwargs["userPolicy"]
  loginType = kwargs["loginType"]
  fctids = kwargs["fctids"]

  if loginType == "userpass":
    client.write(f"""auth/userpass/users/{bankId}""", password=pwd, policies=userPolicy)
    return client.read(f"""auth/userpass/users/{bankId}""")
  else:
    """
    Have not test ldap yet. It might appears it might needs group as well
    $ vault write auth/ldap/groups/engineers policies=foobar
    $ vault write auth/ldap/users/tesla groups=engineers policies=zoobar
    """
    client.write(f"""auth/ldap/users/{bankId}""", policies=userPolicy)
    if fctids:
      client.write(f"""/secret/1bankid/{bankId}/fctids""", fctids = fctids)
    return client.read(f"""auth/ldap/users/{bankId}""")


def list_policies(*args, **kwargs):
  """
  bankid, fct1, fct2, admin=True, provision=True, audit=True 
  """
  policies = "APPS,user-${primary}"
  for pol in [ 'admin', 'provision', 'audit' ]:
    if pol in kwargs and kwargs[pol]:
      policies += "," + pol
