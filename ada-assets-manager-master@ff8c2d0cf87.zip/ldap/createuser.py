"""
Creates the users and groups in LDAP.

Collect the keytabs.

python createuser.py ../ada-assets/**/*.yaml
"""

import ldap
import os
#from ldap.controls import SimplePagedResultsControl
import sys
import ldap.modlist as modlist
import yaml
import argparse
import subprocess
import glob
import fnmatch
from subprocess import Popen,PIPE,call

def check_ldap():

    # LDAP connection
    try:
        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, 0)
        ldap_connection = ldap.initialize(LDAP_SERVER)
        ldap_connection.simple_bind_s(BIND_DN, BIND_PASS)
        return ldap_connection
    except ldap.LDAPError as error_message:
        print("Error connecting to LDAP server: %s" % error_message)
        return False

def gen_keytab(userPrincipalName, password):
    """
    Generate the keytab
    """
    # hive/alluxio@SVCSUAT.DBS.COM -> hive-alluxio.keytab
    filename = userPrincipalName.split('@')[0].replace('/', '-')  + '.' + 'keytab'
    directory = 'KEYTABS'

    if not os.path.exists(directory):
        try:
            os.makedirs(directory)
        except:
            print("Unexpected error:", sys.exc_info()[0])
            raise

    for enc in ['rc4-hmac', 'aes256-cts']:
        call('printf "%b" "addent -password -p ' + userPrincipalName + ' -k 1 -e ' + enc + '\\n' +
            password + '\\n' + 'write_kt ' + directory + '/' + filename + '" | ktutil', shell=True)

def reset_password(ldap_connection, user_name, user_dn, password):
    """
    Set/Reset the password
    """
    count = 0
    while (count < 6): # sometimes it fails, try again.
        try:
            # Prep the password
            unicode_pass = unicode('\"' + password + '\"', 'iso-8859-1')
            password_value = unicode_pass.encode('utf-16-le')
            add_pass = [(ldap.MOD_REPLACE, 'unicodePwd', [password_value])]

            ldap_connection.modify_s(user_dn, add_pass)
            text = user_name + ':'+ password + '\n'
            passlog.write(text)
            count = 6
            break

        except ldap.LDAPError as error_message:
            if count == 6:
                print("Error setting password: %s" % error_message)
                return False
            count += 1

    return True

def create_user(ldap_connection, uid, gid, loginshell, user_groups, user_name, user_dn, userPrincipalName, user_dscr, instance_name=''):
    # Lets build our user: set it in disabled mode at first (514)
    user_attrs = {}
    user_attrs['objectClass'] = ['top', 'person', 'organizationalPerson', 'user']
    user_attrs['distinguishedName'] = 'cn=' + user_name + ',' + base_dn
    user_attrs['sAMAccountName'] = user_name
    user_attrs['userPrincipalName'] = userPrincipalName
    user_attrs['accountExpires'] = '0'
    user_attrs['description'] = user_dscr
    user_attrs['userAccountControl'] = str(ACCOUNTDISABLE + NORMAL_ACCOUNT)
    user_attrs['uid'] = user_name
    user_attrs['msSFU30Name'] = user_name
    user_attrs['msSFU30NisDomain'] = RLM
    user_attrs['uidNumber'] = str(uid)
    user_attrs['gidNumber'] = str(gid)
    user_attrs['unixHomeDirectory'] = '/home/' + user_name
    user_attrs['loginShell'] = loginshell
    #  user_attrs['servicePrincipalName'] = SERV_PRINC

    print("Create user_attrs %s" % user_attrs)

    user_ldif = modlist.addModlist(user_attrs)


    # 66048 will set user account to enabled # 512 came default
    mod_acct = [(ldap.MOD_REPLACE, 'userAccountControl', '66048')]

    '''

    # Replace the primary group ID
    mod_pgid = [(ldap.MOD_REPLACE, 'primaryGroupID', GROUP_TOKEN)]
    # Delete the Domain Users group membership
    del_member = [(ldap.MOD_DELETE, 'member', user_dn)]

    '''

    # Add the new user account
    try:
        ldap_connection.add_s(user_dn, user_ldif)
    except ldap.LDAPError as ldap_error:
        print("Error adding new user: %s" % ldap_error)
        # return False

    return mod_acct

def set_groups(ldap_connection, user_dn, user_groups, env_code):
    # Add user to their primary group
    try:
        # New group membership
        for group_name in user_groups:
            group_name = group_name.format(env_code=env_code)
            GROUP_DN = 'cn=' + group_name + ',' +  base_dn
            add_member = [(ldap.MOD_ADD, 'member', user_dn)]
            ldap_connection.modify_s(GROUP_DN, add_member)
    except ldap.LDAPError as error_message:
        print("Error adding user to group: " % error_message)
        return False

def enable_account(ldap_connection, user_dn, mod_acct):
    # Change the account back to enabled
    try:
        ldap_connection.modify_s(user_dn, mod_acct)
    except ldap.LDAPError as error_message:
        print("Error enabling user: %s" % error_message)
        return False
    return True

def upsert_user(uid, gid, loginshell, user_groups, user_name, user_dscr, instance_name='', just_reset_password=False, do_delete=False, env_code='b'):
    """
    Create/Regenerate a new user account in Active Directory.
    """

    user_name = user_name.format(env_code=env_code)

    # Check and see if user exists
    try:
        print("Searching for user_name=" + user_name + " from " + base_dn)
        user_results = ldap_connection.search_s(base_dn, ldap.SCOPE_SUBTREE,
                        '(&(sAMAccountName=' + user_name + ')(objectClass=person))',
                        ['distinguishedName'])
        if len(user_results) == 1:
            userDistinguishedName = user_results[0][1]['distinguishedName'][0]
            if do_delete:
                print("Deleting " + userDistinguishedName)
                ldap_connection.delete(userDistinguishedName)
                user_results = []
    except ldap.LDAPError as ldap_error:
        if not 'NO_OBJECT' in str(ldap_error):
            print("Error finding user_name " + user_name + ": " % ldap_error)
            return False
        else:
            user_results = []

    if do_delete:
        return

    if instance_name:
        userPrincipalName = user_name + '/' + instance_name + '@' + domain
    else:
        userPrincipalName = user_name + '@' + domain
    user_dn = 'cn=' + user_name + ',' + base_dn
    password = os.popen('openssl rand -base64 32 | tr -d "=+/" | cut -c1-12').read().strip('\n')

    # Check the results
    if len(user_results) != 0:
        if just_reset_password:
            print("Resetting the password and keytab of user " + userDistinguishedName + " that already exists in AD.")
            if not reset_password(ldap_connection, user_name, user_dn, password):
                print("ERROR!: Failed to reset the password for " + user_name)
                return False
            gen_keytab(userPrincipalName, password)
            return
        else:
            print("User " + userDistinguishedName + " already exists in AD. Nothing to do.")
            return False
    else:
        if just_reset_password:
            print("The user " + user_name + " that password should be reset does not exists in AD: creating the user.")
        just_reset_password = False

    mod_acct = create_user(ldap_connection, uid, gid, loginshell, user_groups, user_name, user_dn, userPrincipalName, user_dscr, instance_name)

    # Set/Reset the password
    if not reset_password(ldap_connection, user_name, user_dn, password):
        print("ERROR!: Failed to set the password for " + user_name)
        return False
    print("Password for " + user_name + " is set")

    if not enable_account(ldap_connection, user_dn, mod_acct):
        print("ERROR!: Failed to enable the account for " + user_name)
        return False

    set_groups(ldap_connection, user_dn, user_groups, env_code)
    print("Groups set for " + user_name)

    gen_keytab(userPrincipalName, password)
    print("Keytab generated for " + user_name)

    '''
    # Modify user's primary group ID
    try:
        ldap_connection.modify_s(user_dn, mod_pgid)
    except ldap.LDAPError, error_message:
        print("Error changing user's primary group: %s", error_message)
        return False

    # Remove user from the Domain Users group
    try:
        ldap_connection.modify_s(DU_GROUP_DN, del_member)
    except ldap.LDAPError, error_message:
        print("Error removing user from group: %s", error_message)
        return False

    # LDAP unbind
    ldap_connection.unbind_s()

    '''


def upsert_group(gid, group_dscr, group_name, env_code):

    group_name = group_name.format(env_code=env_code)

    global GROUP_DN
    GROUP_DN = 'cn=' + group_name + ',' +  base_dn
 
  # Check and see if user exists
    try:
        group_results = ldap_connection.search_s(base_dn, ldap.SCOPE_SUBTREE,
            '(&(sAMAccountName=' + group_name + ')(objectClass=group))',
            ['distinguishedName'])
    except ldap.LDAPError as ldap_error:
      print("Error finding group_name: %s" % ldap_error)
      return False

  # Check the results
    if len(group_results) != 0:
        print("Group " + group_results[0][1]['distinguishedName'][0] + " already exists in AD:")
        return False

    grp_attrs = {}
    grp_attrs['objectclass'] = ['top','group']
    grp_attrs['cn'] = group_name
    grp_attrs['description'] = group_dscr
    grp_attrs['distinguishedName'] = GROUP_DN
    grp_attrs['instanceType'] = '4'
    grp_attrs['name'] = group_name
    grp_attrs['sAMAccountName'] = group_name
    grp_attrs['objectCategory'] = 'CN=Group,CN=Schema,CN=Configuration,'+ RLM_BASE_DC
    grp_attrs['msSFU30Name'] = group_name
    grp_attrs['msSFU30NisDomain'] = RLM_DC.lower()
    grp_attrs['gidNumber'] = str(gid)

    grp_ldif = modlist.addModlist(grp_attrs)


    try:
        ldap_connection.add_s(GROUP_DN, grp_ldif)
    except ldap.LDAPError as ldap_error:
        print("Error adding new group: " % ldap_error)
        return False


def usage():
    print("""
py_ldap(_ldapserver, _binddn, _bindpass, file_globs, _base_dn,
        users_to_select_globs, users_to_just_reset_password_globs, users_to_delete_globs)
Mandatory Fields:
LDAP_SERVER: AD Server with port to connect to, for example: "ldaps://w01s1svcsdcs1a.SVCSUAT.DBS.COM:636"
BIND_DN: Bind Domain name to connect to, for example: testuser@SVCSUAT.DBS.COM
BIND_PASS: BIND_DN\'s password
file_globs: comma separated list of glob patterns to select the Yaml files
BASE_DN: BASE Domain name detail, for example:ou=ADA,ou=APPS,dc=SVCSUAT,dc=DBS,dc=COM
""")


def py_ldap(_ldapserver='', _binddn='', _bindpass='', file_globs=[], _base_dn='',
            users_to_select_globs=['*'], users_to_just_reset_password_globs=[], users_to_delete_globs=[], environment='dev'):

    env_code = {
        'dev': 'b',
        'sit': 'b',
        'uat': 's',
        'prod': 'g'
    }[environment]

    global LDAP_SERVER
    LDAP_SERVER = _ldapserver

    global BIND_DN
    BIND_DN = _binddn

    global domain
    domain = BIND_DN.split('@')[1]

    global BIND_PASS
    BIND_PASS = _bindpass

    global SERV_PRINC
    SERV_PRINC = 'ok'

    global AGE_SIZE
    AGE_SIZE = 10

    global ACCOUNTDISABLE
    ACCOUNTDISABLE = 2

    global NORMAL_ACCOUNT
    NORMAL_ACCOUNT = 512

    global RLM_BASE_DC
    RLM_BASE_DC = ''

    global base_dn
    base_dn = _base_dn

    global RLM
    RLM = domain.split('.')[0]
    global RLM_DC
    RLM_DC = 'dc=' + RLM.split('.')[0]

    for val in domain.split('.'):
      RLM_BASE_DC += 'dc='+ val + ','
    RLM_BASE_DC = RLM_BASE_DC[:-1]

#    open('passfile', 'w').close()
    global passlog
    try:
        passlog = open('passfile','a')

        ldap.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, 0)
        ldap_connection1 = ldap.initialize(LDAP_SERVER)
        global ldap_connection
        ldap_connection = ldap_connection1
        ldap_connection.simple_bind_s(BIND_DN, BIND_PASS)

        gids = {} # group_name -> gid

        for file_glob in file_globs:
            if os.path.isdir(file_glob):
                file_glob = file_glob + os.sep + "**" + os.sep + "*.yaml"

            # Load the groups first and collect the gids
            for file in glob.glob(file_glob):
                if file.endswith('.yaml'):
                    _py_ldap_groups(gids=gids, data_file=file, env_code=env_code)

            for file in glob.glob(file_glob):
                if file.endswith('.yaml'):
                    _py_ldap_users(gids=gids, data_file=file,
                            users_to_just_reset_password_globs=users_to_just_reset_password_globs,
                            users_to_select_globs=users_to_select_globs,
                            env_code=env_code)

    except ldap.LDAPError as error_message:
        print("Error connecting to LDAP server: %s", error_message)
        return False
    finally:
        try:
            passlog.close()
        except:
            print('Failed to close the passlog')
        # LDAP unbind
        try:
            ldap_connection.unbind_s()
        except:
            print('Failed to close the ldap connection')

def _glob_str(str, globs=[], env_code='b'):
    for select in globs:
        if fnmatch.fnmatch(str, select):
            return True
        if fnmatch.fnmatch(str.format(env_code=env_code), select):
            return True
    return False

def _py_ldap_groups(gids={}, data_file='', env_code='b'):
    print("Loading " + data_file)

    app_yaml = yaml.load(open(data_file))

    groups = app_yaml['groups']
    for group in groups:
        group_dscr = ''
        if 'description' in group:
            group_dscr = group['description']
#       print(grp_argument)
        group_name = group['name']
        gids[group_name] = group['gid']
        upsert_group(group_dscr=group_dscr, group_name=group_name, gid=group['gid'], env_code=env_code)

    return gids


def _py_ldap_users(gids={}, data_file='', users_to_just_reset_password_globs=[],
        users_to_select_globs=['*'], users_to_delete_globs=[], env_code='b'):
    print("Loading " + data_file)

    app_yaml = yaml.load(open(data_file))

    users = app_yaml['users']
    for user in users:
        user_name = user['name']
        if not _glob_str(user_name, users_to_select_globs, env_code):
            continue # Skip this one.
        user_dscr = ''
        if 'description' in user:
            user_dscr = user['description']
        loginshell = ''
        if 'loginshell' in user:
            loginshell = user['loginshell']
        instance_name = ''
        if 'instance_name' in user:
            instance_name = user['instance_name']
        user_groups = user['groups']
        primary_group = user_groups.pop(0)
        if not primary_group in gids:
            print(gids)
            print("Error: unknown primary group " + primary_group)
        gid = gids[primary_group]

        just_reset_password = _glob_str(user_name, users_to_just_reset_password_globs, env_code)
        do_delete = _glob_str(user_name, users_to_delete_globs, env_code)
        upsert_user(gid=gid, user_name=user_name, user_groups=user_groups, user_dscr=user_dscr,
                uid=user['uid'], loginshell=loginshell, instance_name=instance_name,
                just_reset_password=just_reset_password, do_delete=do_delete, env_code=env_code)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="Setup the ldap users and groups defined in the assets. Generate the keytabs and download them")

    parser.add_argument("-d", "--directory", dest="directory", required=True, help="yml directory or list of globs to select the asset descriptors")
    parser.add_argument("-v", "--verbose", dest="verbose", required=False, help="verbose output if set to True")
    parser.add_argument("-e", "--env", dest="environment", required=True, help='environment: dev, uat or prod')

    args = parser.parse_args()

    # py_ldap(_ldapserver='', _binddn='', _bindpass='', file_globs=[], _base_dn='',
    #         users_to_select_globs=['*'], users_to_just_reset_password_globs=[], users_to_delete_globs=[], environment=args.environment):