# ADA Assets

This repository stores the assets on-boarded onto ADA:

- Applications
- Functional IDs and Groups
- Association of 1bank IDs to Functional IDs for sign-on purpose
- Folders and hive databases

## On-boarding ADA

To on-board ADA, please make a branch and prepare a pull request.

The proposed change will be reviewed and approved by the application owner.

## Downloading a keytab for dev/uat

With vault downloaded from https://www.vaultproject.io/downloads.html

```bash
$ export VAULT_ADDR=https://vault.dev6.nonprod.c0.dbs.com
$ export VAULT_SKIP_VERIFY=1

$ vault login -method=ladap username=my1bankid
Password (will be hidden):
Success! You are now authenticated. The token information below is already
stored in the token helper. You do NOT need to run "vault login" again. Future
requests will use this token automatically.

token: a700ded8-28ed-907d-abf4-23514b783d52
accessor: e0857619-3912-9981-4e03-8d6c4b2f6c56
duration: 24h
renewable: true
policies: [1bankid_my1bankid default]

$ vault read -field=fctids secret/1bankid/my1bankid
fctid1,fctid2

$ vault read -field=keytab secret/fctid/fctid1/keytab | base64 --decode > fctid1.keytab
```

With curl

```bash
$ curl -k --request POST --data '{"password":"YOUR_PASSWORD123"}' "$VAULT_ADDR"/v1/auth/ldap/login/my1bankid
{"request_id":"317780c7-f2f4-1b96-f08c-3b1e954a4d14","lease_id":"","renewable":false,"lease_duration":0,"data":{},"wrap_info":null,"warnings":null,"auth":{"client_token":"THE-VAULT_TOKEN-TO-EXTRACT","accessor":"bbc3cd93-3e8d-61cc-a0cf-022013515d1f","policies":["1bankid_my1bankid","default"],"metadata":{"username":"my1bankid"},"lease_duration":2764800,"renewable":true,"entity_id":"3dc28198-6422-5fb4-a090-38c7791593f2"}}

$ VAULT_TOKEN=THE-VAULT_TOKEN-TO-EXTRACT
$ curl -H "X-Vault-Token: $VAULT_TOKEN" -X GET $VAULT_ADDR/v1/secret/fctid/fctid1/keytab
{"request_id":"c764a44c-8681-8122-fd8b-94644095c7a1","lease_id":"","renewable":false,"lease_duration":2764800,"data":{"keytab":"BASE_64_ENC_KEYTAB"},"wrap_info":null,"warnings":null,"auth":null}
```
