# ada-airflow

This repository is forked from https://github.com/puckel/docker-airflow. It contains **Dockerfile** of [apache-airflow](https://github.com/apache/incubator-airflow) for automated build of [Docker](https://www.docker.com/) images for ADA Data Platform (http://repos.dev6.nonprod.c0.dbs.com:7180/ada-airflow/) .

## Informations

* Based on Python (3.6-slim) official Image [python:3.6-slim](https://hub.docker.com/_/python/) and uses the official [Postgres](https://hub.docker.com/_/postgres/)/[mysql](https://hub.docker.com/_/mysql/)/[mariadb](https://hub.docker.com/_/mariadb/) as backend and [Redis](https://hub.docker.com/_/redis/) as queue
* Install [Docker](https://www.docker.com/)
* Install [Docker Compose](https://docs.docker.com/compose/install/)
* Following the Airflow release from [Python Package Index](https://pypi.python.org/pypi/apache-airflow)

## Installation

curl -O http://repos.dev6.nonprod.c0.dbs.com:7180/ada-airflow/1.9.0/ada-airflow-1.9.0.tar
docker import ada-airflow-1.9.0.tar

## Build

For example, if you need to install [Extra Packages](https://airflow.incubator.apache.org/installation.html#extra-package), edit the Dockerfile and then build it.

    docker build --rm -t dbs/ada-airflow .

Don't forget to update the airflow images in the docker-compose files to puckel/docker-airflow:latest.

## Usage

By default, docker-airflow runs Airflow with **SequentialExecutor** :

    docker run -d -p 8080:8080 dbs/ada-airflow

If you want to run another executor, use the other docker-compose.yml files provided in this repository.

For **LocalExecutor** :

    docker-compose -f docker-compose-LocalExecutor.yml up -d

For **CeleryExecutor** :

    docker-compose -f docker-compose-CeleryExecutor.yml up -d

    