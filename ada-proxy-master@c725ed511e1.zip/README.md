# Squid Proxy
 
- S3 VPC endpoints should be used by applications going forward to ensure S3 access is controlled as the squid proxy can not control which bucket is connected to.
- Changes to the proxy config result in a new deployment once happy that the changes are OK the cutover is done by running the release job from your CI/CD tool (Jenikins/Bamboo/Bitbucket) which will cause an update to DNS.
- The Squid proxy scales to a maximum of 10 instances based on squid metrics collected from a crontab obtained from the squid manager process and sent to cloudwatch where an alarm triggers the scaling. It will scale back down when traffic volume decreases.

## Whitelist changes

- To make changes to the whitelist or add a new product these two files must be modified:
  - Create a new product and add its whitelisted source IP addresses in this example there are two zones/ (prod and nonprod)

 > ansible/roles/proxy/vars/main.yml

```
squid_manager_port: 3129
# Product IP ranges
# Each zone must have an assosciated whitelist in files/squid/*lists/ (blacklists
are optional)
product_source_ips:
  prod:
    - 10.118.0.0/16
  nonprod:
    - 10.119.0.0/16
```

Add the products whitelisted domains by creating a file in the following directory that exactly matches the name of the service created under ```product_source_ips``` you added in the previous step in this example a new file must be created for prod and nonprod above in the following locations:
 > ansible/roles/proxy/files/squid/product-whitelists/prod
 > ansible/roles/proxy/files/squid/product-whitelists/nonprod


Once you code is tested in develop and committed to master your can run a deployment and test against its DeploymentDNS (in the CFN stacks output) ensure your correctly test the functionality of the proxy and check the cache.log file for any startup errors or config errors reported.
Once you are happy you can run the Release job to cutover DNS. Clients will start using the new deployment you should wait untill all clients are using the new DNS before teardown of the old deployment.

## Deploy from local workstation

```
export AWS_PROFILE=dbs-automation
export AWS_DEFAULT_REGION=ap-southeast-1
BUILD=5
BRANCH=master

cd ~/dbs/git/dbs-coreservices-proxy
bash ../dbs-core-automation/bin/run.sh package upload --client dbs --portfolio coreservices --app proxy --branch ${BRANCH} --build $BUILD

cd ~/dbs/git/dbs-core-automation/lambdas/component_compiler
python3.6 cli.py dbs coreservices proxy ${BRANCH}  $BUILD
```

## Run locally

```
cd ../execute
python3.6 simulate.py deploy dbs coreservices proxy ${BRANCH}  $BUILD
```

## Or you can run from runner

```
#bash ~/dbs/git/dbs-core-automation/bin/run.sh deploy  --client dbs --portfolio coreservices --app proxy --branch ${BRANCH}  --build $BUILD
```

## Test ansible deployment locally

```
rm -rf ansible*
aws s3 cp  s3://dbs-core-automation-ap-southeast-1/files/build/coreservices/proxy/${BRANCH}/${BUILD}/ansible/ansible.zip ./
unzip -o ansible.zip
aws s3 cp  s3://dbs-core-automation-ap-southeast-1/files/build/core/ansible/master/_latest/ansible/ansible.zip ./
unzip -o ansible.zip
ansible-playbook ansible/ansible.yml -c local
```


