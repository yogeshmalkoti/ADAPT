#!/bin/bash
INSTANCEID=`curl -s 169.254.169.254/latest/meta-data/instance-id`
# availabilityzone=`curl -s 169.254.169.254/latest/meta-data/placement/availability-zone`
# region=`curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep -oP '\"region\"[[:space:]]*:[[:space:]]*\"\K[^\"]+'`
source /etc/profile.d/deployment_information.sh
stackname=${PIPELINE_PORTFOLIO}-${PIPELINE_APP}-${PIPELINE_BRANCH}-${PIPELINE_BUILD}-${PIPELINE_COMPONENT}

#Get stack name without pipeline environment variables
# stackname=`aws ec2 describe-instances \
#   --instance-id $INSTANCEID \
#   --query 'Reservations[*].Instances[*].Tags[?Key==\`aws:cloudformation:stack-name\`].Value' \
#   --output text --region $region`

totalrequests=`squidclient -p {{ squid_manager_port }} mgr:5min | grep "client_http.requests" | cut -d " " -f3 | cut -d "/" -f1`
hitrequests=`squidclient -p {{ squid_manager_port }} mgr:5min | grep "client_http.hits" | cut -d " " -f3 | cut -d "/" -f1`
totalkbytes=`squidclient -p {{ squid_manager_port }} mgr:5min | grep "client_http.kbytes_out" | cut -d " " -f3 | cut -d "/" -f1`
clienthttperr=`squidclient -p {{ squid_manager_port }} mgr:5min | grep "client_http.errors" | cut -d " " -f3 | cut -d "/" -f1`
serverallerr=`squidclient -p {{ squid_manager_port }} mgr:5min | grep "server.all.errors" | cut -d " " -f3 | cut -d "/" -f1`
cachesize=`du -s /var/spool/squid | sed 's/^\([0-9]*\).*/\1/'`

aws cloudwatch put-metric-data --region "${PIPELINE_AWS_REGION}" --namespace "DBS/Coreservices/SquidProxy" --metric-name "TotalRequestsPerSecond" --unit "Count/Second" --dimensions "StackName=${stackname}" --value "$totalrequests"
aws cloudwatch put-metric-data --region "${PIPELINE_AWS_REGION}" --namespace "DBS/Coreservices/SquidProxy" --metric-name "HitRequestsPerSecond" --unit "Count/Second" --dimensions "StackName=${stackname}" --value "$hitrequests"
aws cloudwatch put-metric-data --region "${PIPELINE_AWS_REGION}" --namespace "DBS/Coreservices/SquidProxy" --metric-name "TotalKbytesPerSecond" --unit "Kilobytes/Second" --dimensions "StackName=${stackname}" --value "$totalkbytes"
aws cloudwatch put-metric-data --region "${PIPELINE_AWS_REGION}" --namespace "DBS/Coreservices/SquidProxy" --metric-name "DiskCacheSize" --unit "Kilobytes" --dimensions "StackName=${stackname}" --value "$cachesize"
aws cloudwatch put-metric-data --region "${PIPELINE_AWS_REGION}" --namespace "DBS/Coreservices/SquidProxy" --metric-name "ClientHTTPErrorsPerSecond" --unit "Count/Second" --dimensions "StackName=${stackname}" --value "$clienthttperr"
aws cloudwatch put-metric-data --region "${PIPELINE_AWS_REGION}" --namespace "DBS/Coreservices/SquidProxy" --metric-name "ServerAllErrorsPerSecond" --unit "Count/Second" --dimensions "StackName=${stackname}" --value "$serverallerr"
